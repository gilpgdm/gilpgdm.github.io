import {
  msg
} from "../lib/movil.js";
import "./config.js";

const REQUERIDO = "*Requerido";
const REQUERIDO_NO_0 =
  "*Requerido, no 0";
const NO_0 = "No puede ser 0";

const form =
  document.querySelector("form");

/**
 * @type {HTMLInputElement|null}
 */
const inA =
  document.querySelector("#inA");

/**
 * @type {HTMLOutputElement|null}
 */
const msgA =
  document.querySelector("#msgA");

/**
 * @type {HTMLInputElement| null}
 */
const inB =
  document.querySelector("#inB");

/**
 * @type {HTMLOutputElement|null}
 */
const msgB =
  document.querySelector("#msgB");

if (inA && inB && form) {
  inA.addEventListener("input",
    () => msg(inA, msgA,
      REQUERIDO));
  inB.addEventListener("input",
    validaB);
  form.addEventListener(
    "submit", divide);
}

function validaB() {
  if (inB) {
    const b = inB.valueAsNumber;
    if (isNaN(b) || b !== 0) {
      inB.setCustomValidity("");
    } else {
      inB.setCustomValidity(NO_0);
    }
    msg(inB, msgB,
      REQUERIDO_NO_0);
  }
}

/** @param {Event} evt */
function divide(evt) {
  evt.preventDefault();
  if (inA && inB && form) {
    try {
      if (inA.validity.valid &&
        inB.validity.valid) {
        const a =
          inA.valueAsNumber;
        const b =
          inB.valueAsNumber;
        form.outSalida.value =
          a / b;
      } else {
        form.outSalida.value = "";
      }
    } catch (e) {
      console.error(e);
      form.outSalida.value =
        e.message;
    }
  }
}