import "../lib/cmp-din.js";
import {
  regSw
} from "../lib/movil.js";
import "./mi-nav.js";

regSw("sw.js");