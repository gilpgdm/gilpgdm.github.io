import {
 msg
} from "../lib/movil.js"
import "./config.js"

const REQUERIDO = "*Requerido"
const form =
 document.querySelector("form")

/**
 * @type {HTMLInputElement|null}
 */
const inGenero = document.
 querySelector("#inGenero")

/**
 * @type {HTMLOutputElement|null}
 */
const msgGenero = document.
 querySelector("#msgGenero")

if (inGenero !== null
 && form !== null) {
 inGenero.addEventListener("input",
  () => msg(inGenero, msgGenero,
   REQUERIDO))
 form.addEventListener("submit",
  recomienda)
}

/** @param {Event} evt */
function recomienda(evt) {
 evt.preventDefault()
 if (inGenero !== null
  && form !== null) {
  const outSalida = form.outSalida
  try {
   if (inGenero.validity.valid) {
    const genero = inGenero.value
    if (genero === "pop") {
     outSalida.value =
      `Te recomiendo a
       Ariana Grande.`
    } else if (genero
     === "regueton") {
     outSalida.value =
      "Te recomiendo a Bad Bunny."
    } else {
     outSalida.value =
      "De ese género no conozco."
    }
   } else {
    outSalida.value = ""
   }
  } catch (e) {
   console.error(e)
   outSalida.value = e.message
  }
 }
}