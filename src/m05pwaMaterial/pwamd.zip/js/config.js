import "../lib/js/detecta.js"
import {
 regSw
} from "../lib/js/regSw.js"

regSw("sw.js")