import "../lib/js/md3.js"
import "../js/mi-nav.js"
import {
 regSw
} from "../lib/js/regSw.js"

regSw("sw.js")