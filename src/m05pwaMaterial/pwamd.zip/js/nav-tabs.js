const SEL = "sel"
export class NavTabs
 extends HTMLElement {
 connectedCallback() {
  this.innerHTML = /* html */
   `<a href="index.html">
     <span class="material-icons">
      home
     </span>
     Recomiendo
    </a>
    <a href="ayuda.html">
     <span class="material-icons">
      help
     </span>
     Ayuda
    </a>`
  const href = location.href
  const index = this.querySelector(
   "[href='index.html']")
  const ayuda = this.querySelector(
   "[href='ayuda.html']")
  if (ayuda != null &&
   href.endsWith("ayuda.html")) {
   ayuda.classList.add(SEL)
  } else if (index != null) {
   index.classList.add(SEL)
  }
 }
}
customElements.define(
 "nav-tabs", NavTabs)