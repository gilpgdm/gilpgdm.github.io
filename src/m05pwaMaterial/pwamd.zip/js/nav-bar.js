export class NavBar
 extends HTMLElement {

 connectedCallback() {
  this.classList.add("navBar")

  this.innerHTML = /* html */
   `<a id="aIndex"
      href="index.html">
     <span
 class="material-symbols-outlined">
      home
     </span>
     Inicio
    </a>

    <a id="aSecundario"
      href="secundaria.html">
     <span
class="material-symbols-outlined">
      scrollable_header
     </span>
     Página secundaria
    </a>

    <a id="aNavBar"
      href="navbar.html">
     <span
class="material-symbols-outlined">
      bottom_navigation
     </span>
     Barra de navegación
    </a>

    <a id="aNavTab"
      href="navtab.html">
     <span
class="material-symbols-outlined">
      swipe_left
     </span>
     Pestañas scrollable
    </a>

    <a id="aAyuda"
      href="ayuda.html">
     <span
 class="material-symbols-outlined">
      help
     </span>
     Ayuda
    </a>`

 }

}

customElements.define(
 "nav-bar", NavBar)