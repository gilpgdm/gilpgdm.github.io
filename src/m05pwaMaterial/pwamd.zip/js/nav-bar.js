export class NavBar
 extends HTMLElement {

 connectedCallback() {
  this.classList.add("navBar")

  this.innerHTML = /* html */
   `<a id="aIndex"
      href="index.html">
     <span
 class="material-symbols-outlined">
      home
     </span>
     Inicio
    </a>

    <a id="aSecundario"
      href="secundaria.html">
     <span
class="material-symbols-outlined">
      list
     </span>
     Secundaria
    </a>

    <a id="aNavBar"
      href="navbar.html">
     <span
class="material-symbols-outlined">
      list
     </span>
     Navegación
    </a>

    <a id="aFormulario"
      href="formulario.html">
     <span
class="material-symbols-outlined">
      newspaper
     </span>
     Formulario
    </a>

    <a id="aAyuda"
      href="ayuda.html">
     <span
 class="material-symbols-outlined">
      help
     </span>
     Ayuda
    </a>`

 }

}

customElements.define(
 "nav-bar", NavBar)