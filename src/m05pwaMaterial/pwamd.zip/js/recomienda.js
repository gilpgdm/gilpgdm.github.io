/** @param {string} genero */
export
 function recomienda(genero) {
 if (genero === "pop") {
  return "Ariana Grande."
 } else if (genero === "reg") {
  return "Bad Bunny."
 } else {
  return "De eso no conozco."
 }
}