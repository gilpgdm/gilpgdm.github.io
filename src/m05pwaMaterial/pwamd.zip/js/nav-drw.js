import {
 OPEN_CLASS
} from "../lib/js/constantes.js"

export class NavDrw
 extends HTMLElement {

 connectedCallback() {
  this.classList.add("navDrw")

  this.innerHTML = /* html */
   `<button type="button"
      class="icon"
      onclick="drawer
       .classList
       .add('${OPEN_CLASS}')">
     <span
 class="material-symbols-outlined">
      menu
     </span>
    </button>

    <div id=drawer>

     <ul>

      <li>
       <h2>
        PWA con Material Design
       </h2>
      </li>

      <li>
       <a id="aIndex"
         href="index.html">
        <span
 class="material-symbols-outlined">
         home
        </span>
        Inicio
       </a>
      </li>

      <li>
       <a id="aSecundario"
         href="secundaria.html">
        <span
 class="material-symbols-outlined">
         scrollable_header
        </span>
        Página secundaria
       </a>
      </li>

      <li>
       <a id="aIconos"
         href="iconos.html">
        <span
 class="material-symbols-outlined">
          sentiment_satisfied
         </span>
         Íconos
       </a>
      </li>

      <li>
       <a id="aCampos"
         href="campos.html">
        <span
 class="material-symbols-outlined">
         password
        </span>
        Campos
       </a>
      </li>

      <li>
       <a id="aSlider"
         href="slider.html">
        <span
 class="material-symbols-outlined">
         linear_scale
        </span>
        Sliders
       </a>
      </li>

      <li>
       <a id="aSelect"
         href="select.html">
        <span
 class="material-symbols-outlined">
         bottom_panel_close
        </span>
        Select
       </a>
      </li>

      <li>
       <a id="aBotones"
         href="botones.html">
        <span
 class="material-symbols-outlined">
         right_click
        </span>
        Botones
       </a>
      </li>

      <li>
       <a id="aSegmentado"
         href="segmentado.html">
        <span
 class="material-symbols-outlined">
         splitscreen_left
        </span>
        Botón segmentado
       </a>
      </li>

      <li>
       <a id="aListas"
         href="listas.html">
        <span
 class="material-symbols-outlined">
         lists
        </span>
        Listas
       </a>
      </li>

      <li>
       <a id="aTarjetas"
         href="tarjetas.html">
        <span
 class="material-symbols-outlined">
         cards
        </span>
        Tarjetas
       </a>
      </li>

      <li>
       <a id="aNavTab"
         href="navtab.html">
        <span
 class="material-symbols-outlined">
         swipe_left
        </span>
        Pestañas scrollable
       </a>
      </li>

      <li>
       <a id="aNavTabFixed"
         href="navTabFixed.html">
        <span
 class="material-symbols-outlined">
         tabs
        </span>
        Pestañas fijas
       </a>
      </li>

      <li>
       <a id="aNavBar"
         href="navbar.html">
        <span
 class="material-symbols-outlined">
         bottom_navigation
        </span>
        Barra de navegación
       </a>
      </li>

      <li>
       <a id="aFormulario"
         href="formulario.html">
        <span
 class="material-symbols-outlined">
         newspaper
        </span>
        Formulario
       </a>
      </li>

      <li>
       <a id="aAyuda"
         href="ayuda.html">
        <span
 class="material-symbols-outlined">
         help
        </span>
        Ayuda
       </a>
      </li>

     </ul>

    </div>

    <div class="scrim"
      onclick="drawer
       .classList
       .remove('${OPEN_CLASS}')">
    </div>`
 }

}

customElements.define(
 "nav-drw", NavDrw)