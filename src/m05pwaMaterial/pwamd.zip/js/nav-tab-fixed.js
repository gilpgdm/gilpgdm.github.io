export class NavTabFixed
 extends HTMLElement {

 connectedCallback() {
  this.classList
   .add("navTab", "fixed")

  this.innerHTML = /* html */
   `<a id="aIndex"
      href="index.html">
     <span
 class="material-symbols-outlined">
      home
     </span>
     Inicio
    </a>

    <a id="aNavTab"
      href="navtab.html">
     <span
class="material-symbols-outlined">
      list
     </span>
     Pestañas
     <br>scrollable
    </a>

    <a id="aNavTabFixed"
      href="navTabFixed.html">
     <span
class="material-symbols-outlined">
      list
     </span>
     Pestañas
     <br>fijas
    </a>

    <a id="aAyuda"
      href="ayuda.html">
     <span
 class="material-symbols-outlined">
      help
     </span>
     Ayuda
    </a>`

 }

}

customElements.define(
 "nav-tab-fixed", NavTabFixed)