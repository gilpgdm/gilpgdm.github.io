import "../lib/detecta.js"
import {
 regSw
} from "../lib/regSw.js"

regSw("sw.js")