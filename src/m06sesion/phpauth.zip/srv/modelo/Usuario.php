<?php
require_once __DIR__ .
 "/../textos/txtFaltaElCue.php";
require_once __DIR__ .
 "/../textos/txtFaltaElMatch.php";

class Usuario
{
 public $id;
 public $cue;
 public $match;
 public function valida()
 {
  if (
   $this->cue === null
   || $this->cue === ""
  ) {
   throw new Exception(
    txtFaltaElCue()
   );
  }
  if (
   $this->match === null
   || $this->match === ""
  ) {
   throw new Exception(
    txtFaltaElMatch()
   );
  }
 }
}
