<?php
function bdCrea(\PDO $con)
{
 $con->exec(
  'CREATE TABLE
   IF NOT EXISTS USUARIO (
   USU_ID INTEGER PRIMARY KEY,
   USU_CUE TEXT UNIQUE NOT NULL,
   USU_MATCH TEXT NOT NULL
   )'
 );
}
