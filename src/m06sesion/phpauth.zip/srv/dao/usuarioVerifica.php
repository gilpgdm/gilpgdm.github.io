<?php
require_once __DIR__ .
 "/../modelo/Usuario.php";
require_once __DIR__ .
 "/usuarioBusca.php";

function usuarioVerifica(
 string $cue,
 string $match
) {
 $usuario = usuarioBusca($cue);
 if (
  $usuario
  && password_verify(
   $match,
   $usuario->match
  )
 ) {
  return true;
 } else {
  return false;
 }
}
