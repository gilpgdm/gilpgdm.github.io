<?php
require_once __DIR__ .
 "/../modelo/Usuario.php";
require_once __DIR__ .
 "/AccesoBd.php";

function usuarioAgrega(
 Usuario $modelo
) {
 $modelo->valida();
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "INSERT INTO USUARIO
    (USU_CUE, USU_MATCH)
   VALUES
    (:cue, :match)"
 );
 $stmt->execute([
  ":cue" => $modelo->cue,
  ":match" =>
  password_hash(
   $modelo->match,
   PASSWORD_DEFAULT
  )
 ]);
}
