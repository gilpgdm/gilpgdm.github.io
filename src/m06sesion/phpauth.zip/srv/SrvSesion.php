<?php
require_once __DIR__ .
 "/../lib/php/Servicio.php";

class SrvSesion extends Servicio
{
 protected
 function implementacion()
 {
  session_start();
  $cue =
   isset($_SESSION["cue"])
   ? $_SESSION["cue"] : "";
  return ["cue" => $cue];
 }
}

$servicio = new SrvSesion();
$servicio->ejecuta();