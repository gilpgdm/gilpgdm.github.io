export function txtPruebaHumano() {
 return "Comprueba que eres " +
  "humano."
}