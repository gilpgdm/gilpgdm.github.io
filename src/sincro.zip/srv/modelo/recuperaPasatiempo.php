<?php

require_once __DIR__ . "/../../lib/php/BAD_REQUEST.php";
require_once __DIR__ . "/../../lib/php/validaJson.php";
require_once __DIR__ . "/../../lib/php/ProblemDetails.php";
require_once __DIR__ . "/Pasatiempo.php";

function recuperaPasatiempo($objeto)
{

 $objeto = validaJson($objeto);

 if (!isset($objeto->nombre) || !is_string($objeto->nombre))
  throw new ProblemDetails(
   status: BAD_REQUEST,
   title: "El nombre debe ser texto.",
   type: "/error/nombreincorrecto.html",
  );

 if (!isset($objeto->uuid) || !is_string($objeto->uuid))
  throw new ProblemDetails(
   status: BAD_REQUEST,
   title: "El uuid debe ser texto.",
   type: "/error/uuidincorrecto.html",
  );

 if (!isset($objeto->eliminado) || !is_bool($objeto->eliminado))
  throw new ProblemDetails(
   status: BAD_REQUEST,
   title: "El campo eliminado debe ser booleano.",
   type: "/error/eliminadoincorrecto.html",
  );

 if (!isset($objeto->modificacion)  || !is_int($objeto->modificacion))
  throw new ProblemDetails(
   status: BAD_REQUEST,
   title: "La modificacion debe ser número.",
   type: "/error/modificacionincorrecta.html",
  );

 return new Pasatiempo(
  uuid: $objeto->uuid,
  nombre: $objeto->nombre,
  modificacion: $objeto->modificacion,
  eliminado: $objeto->eliminado
 );
}
