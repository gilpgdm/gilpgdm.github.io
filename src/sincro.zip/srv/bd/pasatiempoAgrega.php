<?php

require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/../modelo/Pasatiempo.php";

function pasatiempoAgrega(Pasatiempo $modelo)
{

 $modelo->valida();

 $conexion = Bd::getConexion();

 $conexion->prepare(
  "INSERT INTO PASATIEMPO
    (PAS_UUID, PAS_NOMBRE, PAS_MODIFICACION, PAS_ELIMINADO)
   VALUES
    (:uuid, :nombre, :modificacion, :eliminado)"
 )
  ->execute([
   ":uuid" => $modelo->uuid,
   ":nombre" => $modelo->nombre,
   ":modificacion" => $modelo->modificacion,
   ":eliminado" => $modelo->eliminado ? 1 : 0
  ]);
}
