<?php

require_once __DIR__ . "/../../lib/php/fetch.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/../modelo/Pasatiempo.php";

function pasatiempoBusca(string $uuid): false|Pasatiempo
{

 $conexion = Bd::getConexion();

 return fetch(
  $conexion->prepare(
   "SELECT
    PAS_UUID AS uuid,
    PAS_NOMBRE AS nombre,
    PAS_MODIFICACION AS modificacion,
    PAS_ELIMINADO AS eliminado
   FROM PASATIEMPO
   WHERE PAS_UUID = :uuid"
  ),
  [":uuid" => $uuid],
  PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE,
  Pasatiempo::class
 );
}
