<?php

require_once __DIR__ . "/../modelo/Pasatiempo.php";

class Bd
{

 private static ?PDO $conexion = null;

 static function getConexion(): PDO
 {
  if (self::$conexion === null) {
   self::$conexion = new PDO(
    // cadena de conexión
    "sqlite:sincronizacion.db",
    // usuario
    null,
    // contraseña
    null,
    // Opciones: conexiones persistentes y lanza excepciones.
    [PDO::ATTR_PERSISTENT => true, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
   );

   self::$conexion->exec(
    'CREATE TABLE IF NOT EXISTS PASATIEMPO (
      PAS_UUID TEXT NOT NULL,
      PAS_NOMBRE TEXT NOT NULL,
      PAS_MODIFICACION INTEGER NOT NULL,
      PAS_ELIMINADO INTEGER NOT NULL,
      CONSTRAINT PAS_PK
       PRIMARY KEY(PAS_UUID),
      CONSTRAINT PAS_UUID_NV
       CHECK(LENGTH(PAS_UUID) > 0),
      CONSTRAINT PAS_NOM_NV
       CHECK(LENGTH(PAS_NOMBRE) > 0)
     )'
   );
  }

  return self::$conexion;
 }
}
