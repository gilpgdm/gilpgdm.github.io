import { Pasatiempo } from "./Pasatiempo.js"
import {
 validaPasatiempo
} from "./validaPasatiempo.js"

/** @param { any } objeto */
export function recuperaPasatiempo(objeto) {
 const validado = validaPasatiempo(objeto)
 return new Pasatiempo({
  uuid: validado.uuid,
  nombre: validado.nombre,
  modificacion: validado.modificacion,
  eliminado: validado.eliminado,
 })
}