/**
 * @param { any } objeto
 * @returns { {
 *   uuid: string,
 *   nombre: string,
 *   modificacion: number,
 *   eliminado: boolean,
 *  } }
 */
export function validaPasatiempo(objeto) {

 if (typeof objeto.uuid !== "string")
  throw new Error("El uuid debe ser texto.")

 if (typeof objeto.nombre !== "string")
  throw new Error("El nombre debe ser texto.")

 if (typeof objeto.modificacion !== "number")
  throw new Error("El campo modificacion debe ser número.")

 if (typeof objeto.eliminado !== "boolean")
  throw new Error("El campo eliminado debe ser booleano.")

 return objeto

}