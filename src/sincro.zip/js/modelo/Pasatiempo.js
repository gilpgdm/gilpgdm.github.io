export class Pasatiempo {

 /**
  * @param { {
  *   uuid?: string,
  *   nombre?: string,
  *   modificacion?: number,
  *   eliminado?: boolean,
  * } } modelo
  */
 constructor(modelo) {
  this.nombre = modelo.nombre === undefined
   ? ""
   : modelo.nombre
  this.uuid = modelo.uuid === undefined
   ? ""
   : modelo.uuid
  this.modificacion = modelo.modificacion === undefined
   ? NaN
   : modelo.modificacion
  this.eliminado = modelo.eliminado === undefined
   ? true
   : modelo.eliminado
 }

 validaNuevo() {
  if (this.nombre === "")
   throw new Error("Falta el nombre.")
 }

 valida() {
  if (this.uuid === "")
   throw new Error("Falta el uuid.")
  if (this.nombre === "")
   throw new Error("Falta el nombre.")
 }

}

// Permite que los eventos de html usen la clase.
window["Pasatiempo"] = Pasatiempo