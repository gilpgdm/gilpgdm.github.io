/**
 * @typedef {Object} PASATIEMPO
 * @property {string} PAS_ID
 * @property {string} PAS_NOMBRE
 * @property {number} PAS_MODIFICACION
 * @property {number} PAS_ELIMINADO
 */