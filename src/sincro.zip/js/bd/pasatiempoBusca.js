import { bdConsulta } from "../../lib/js/bdConsulta.js"
import { recuperaPasatiempo } from "../modelo/recuperaPasatiempo.js"
import { Pasatiempo } from "../modelo/Pasatiempo.js"
import { Bd, NOMBRE_DEL_ALMACEN_PASATIEMPO } from "./Bd.js"

/**
 * @param { string | null } uuid
 */
export async function pasatiempoBusca(uuid) {

 if (uuid === null)
  throw new Error("Falta el uuid")

 return bdConsulta(Bd, [NOMBRE_DEL_ALMACEN_PASATIEMPO],
  /**
   * @param { IDBTransaction } transaccion 
   * @param { (resultado: Pasatiempo|undefined) => any } resolve 
   */
  (transaccion, resolve) => {

   /* Pide el primer registro de almacén pasatiempo que tenga como
    * llave primaria el valor del parámetro uuid. */
   const consulta =
    transaccion.objectStore(NOMBRE_DEL_ALMACEN_PASATIEMPO).get(uuid)

   /* onsuccess se invoca solo una vez, devolviendo el registro
   * solicitado. */
   consulta.onsuccess = () => {

    /* Se recupera el registro solicitado usando
     *  consulta.result
     * Si el registro no se encuentra se recupera undefined. */
    const objeto = consulta.result

    if (objeto !== undefined) {
     const modelo = recuperaPasatiempo(objeto)
     if (!modelo.eliminado) {
      resolve(modelo)
     }
    }

    resolve(undefined)

   }

  })

}

// Permite que los eventos de html usen la función.
window["pasatiempoBusca"] = pasatiempoBusca