import { bdEjecuta } from "../../lib/js/bdEjecuta.js"
import { Pasatiempo } from "../modelo/Pasatiempo.js"
import { Bd, NOMBRE_DEL_ALMACEN_PASATIEMPO } from "./Bd.js"

let secuencia = 0

/**
 * @param { Pasatiempo } modelo
 */
export async function pasatiempoAgrega(modelo) {
 modelo.validaNuevo()
 modelo.modificacion = Date.now()
 modelo.eliminado = false

 // Genera uuid único en internet.
 modelo.uuid = Date.now().toString() + Math.random() + secuencia
 secuencia++

 return bdEjecuta(Bd, [NOMBRE_DEL_ALMACEN_PASATIEMPO],
  transaccion => {
   const almacenPasatiempo =
    transaccion.objectStore(NOMBRE_DEL_ALMACEN_PASATIEMPO)
   almacenPasatiempo.add(modelo)
  })
}

// Permite que los eventos de html usen la función.
window["pasatiempoAgrega"] = pasatiempoAgrega