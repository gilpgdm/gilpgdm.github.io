import { bdEjecuta } from "../../lib/js/bdEjecuta.js"
import { Bd, NOMBRE_DEL_ALMACEN_PASATIEMPO } from "./Bd.js"

/**
 * Borra el contenido del almacén pasatiempo y guarda el
 * contenido del listado.
 * @param {any[]} datosNuevos
 */
export async function pasatiemposReemplaza(datosNuevos) {
 return bdEjecuta(Bd, [NOMBRE_DEL_ALMACEN_PASATIEMPO],
  transaccion => {
   const almacenPasatiempo =
    transaccion.objectStore(NOMBRE_DEL_ALMACEN_PASATIEMPO)
   almacenPasatiempo.clear()
   for (const objeto of datosNuevos) {
    almacenPasatiempo.add(objeto)
   }
  })
}