import {
 bdConsulta
} from "../../lib/js/bdConsulta.js"
import {
 conn,
 PASATIEMPO
} from "./conn.js"

/**
 * @param {string} uuid
 * @returns {Promise<
 *  undefined
 *  | {
 *     uuid?:string,
 *     nombre: string
 *     modificacion?: number
 *     eliminado?: number}>
 *    }
 */
export async function
 pasatiempoBusca(uuid) {
 return bdConsulta(conn,
  [PASATIEMPO], (tx, resolve) => {
   const proc = tx.
    objectStore(PASATIEMPO).
    get(uuid)
   proc.onsuccess =
    () => resolve(proc.result)
  })
}