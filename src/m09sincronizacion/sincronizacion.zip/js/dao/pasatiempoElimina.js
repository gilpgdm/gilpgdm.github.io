import {
 pasatiempoBusca
} from "./pasatiempoBusca.js"
import {
 pasatiempoModifica
} from "./pasatiempoModifica.js"

/** @param {string} uuid */
export async function
 pasatiempoElimina(uuid) {
 const modelo =
  await pasatiempoBusca(uuid)
 if (modelo !== undefined) {
  modelo.eliminado = 1
  return pasatiempoModifica(modelo)
 }
}