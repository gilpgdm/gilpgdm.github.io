import {
 validaNombreNoVacio
} from "../../lib/js/validaNombreNoVacio.js"
import {
 validaUuidNoVacio
} from "../../lib/js/validaUuidNoVacio.js"

/**
 * @param {{
*  uuid?:string,
*  nombre: string
*  modificacion?: number
*  eliminado?: number}} modelo
*/
export function pasatiempoValida(
 modelo) {
 validaUuidNoVacio(modelo.uuid)
 validaNombreNoVacio(modelo.nombre)
}