import {
 validaNombreNoVacio
} from "../../lib/js/validaNombreNoVacio.js"

/**
 * @param {{
*  uuid?:string,
*  nombre: string
*  modificacion?: number
*  eliminado?: number}} modelo
*/
export function
 pasatiempoValidaNuevo(modelo) {
 validaNombreNoVacio(modelo.nombre)
}