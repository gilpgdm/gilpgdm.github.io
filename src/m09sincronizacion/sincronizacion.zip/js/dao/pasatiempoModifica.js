import {
 bdEjecuta
} from "../../lib/js/bdEjecuta.js"
import {
 conn,
 PASATIEMPO
} from "./conn.js"
import {
 pasatiempoValida
} from "./pasatiempoValida.js"

/**
 * @param {{
 *  uuid?:string,
 *  nombre: string
 *  modificacion?: number
 *  eliminado?: number}} modelo
 */
export async function
 pasatiempoModifica(modelo) {
 pasatiempoValida(modelo)
 modelo.modificacion = Date.now()
 return bdEjecuta(conn,
  [PASATIEMPO], tx => {
   const store =
    tx.objectStore(PASATIEMPO)
   store.put(modelo)
  })
}