import {
 bdConsulta
} from "../../lib/js/bdConsulta.js"
import {
 conn,
 PASATIEMPO
} from "./conn.js"

/**
 * Lista todos los objetos,
 * incluyendo los que tienen
 * borrado lógico.
 * @returns {Promise<
 *  {
 *   uuid?:string,
 *   nombre: string
 *   modificacion?: number
 *   eliminado?: number} []>
 *  }
 */
export async function
 pasatiempoConsultaTodos() {
 return bdConsulta(conn,
  [PASATIEMPO], (tx, resolve) => {
   const modelos = []
   const proc = tx.
    objectStore(PASATIEMPO).
    openCursor()
   proc.onsuccess = () => {
    const cursor = proc.result
    if (cursor === null) {
     resolve(modelos)
    } else {
     modelos.push(cursor.value)
     cursor.continue()
    }
   }
  })
}