import {
 bdEjecuta
} from "../../lib/js/bdEjecuta.js"
import {
 conn,
 PASATIEMPO
} from "./conn.js"

/**
 * Borra el contenido del almacén y
 * guarda el contenido del listado.
 * @param {Array} lista nuevos
 *   datos. */
export async function
 reemplazaObjetos(lista) {
 return bdEjecuta(conn,
  [PASATIEMPO], tx => {
   const store =
    tx.objectStore(PASATIEMPO)
   store.clear()
   for (const modelo of lista) {
    store.add(modelo)
   }
  })
}