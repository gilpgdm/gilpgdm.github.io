import {
 bdEjecuta
} from "../../lib/js/bdEjecuta.js"
import {
 conn,
 PASATIEMPO
} from "./conn.js"
import {
 pasatiempoValidaNuevo
} from "./pasatiempoValidaNuevo.js"

let secuencia = 0

/**
 * @param {{
 *  uuid?:string,
 *  nombre: string
 *  modificacion?: number
 *  eliminado?: number}} modelo
 */
export async function
 pasatiempoAgrega(modelo) {

 pasatiempoValidaNuevo(modelo)
 modelo.modificacion = Date.now()
 modelo.eliminado = 0
 modelo.uuid = Date.now()
  .toString() + Math.random()
  + secuencia
 secuencia++

 return bdEjecuta(conn,
  [PASATIEMPO], tx => {
   const store =
    tx.objectStore(PASATIEMPO)
   store.add(modelo)
  })
}