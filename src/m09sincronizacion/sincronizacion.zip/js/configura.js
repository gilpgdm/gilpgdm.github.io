import {
 registraServiceWorkerSiEsSoportado
} from "../lib/js/registraServiceWorkerSiEsSoportado.js"

registraServiceWorkerSiEsSoportado(
 "sw.js")