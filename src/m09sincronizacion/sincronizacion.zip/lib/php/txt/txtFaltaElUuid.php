<?php

function txtFaltaElUuid()
{
 return "Falta el uuid.";
}
