<?php

require_once
 "lib/php/validaTextoNoVacio.php";
require_once
 "lib/php/txt/txtFaltaElUuid.php";

function validaUuidNoVacio(
 string $uuid
) {
 validaTextoNoVacio(
  $uuid,
  txtFaltaElUuid()
 );
}
