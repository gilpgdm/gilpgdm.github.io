<?php

use srv\dao\AccesoBd;
use srv\modelo\Pasatiempo;

function pasatiempoModifica(
 Pasatiempo $modelo
) {
 $modelo->valida();
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "UPDATE PASATIEMPO
 SET PAS_NOMBRE = :nombre,
  PAS_MODIFICACION = :modificacion,
  PAS_ELIMINADO = :eliminado
 WHERE PAS_UUID = :uuid"
 );
 $stmt->execute([
  ":uuid" => $modelo->uuid,
  ":nombre" => $modelo->nombre,
  ":modificacion" =>
  $modelo->modificacion,
  ":eliminado" =>
  $modelo->eliminado
 ]);
}
