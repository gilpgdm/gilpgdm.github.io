<?php

require_once
 "lib/php/recibeFetchAll.php";

use srv\dao\AccesoBd;
use srv\modelo\Pasatiempo;

/** @return Pasatiempo[] */
function
pasatiempoConsultaNoEliminados()
{
 $con = AccesoBd::getCon();
 $stmt = $con->query(
  "SELECT
  PAS_UUID AS uuid,
  PAS_NOMBRE AS nombre,
  PAS_MODIFICACION AS modificacion,
  PAS_ELIMINADO AS eliminado
 FROM PASATIEMPO
 WHERE PAS_ELIMINADO = 0"
 );
 $resultado = $stmt->fetchAll(
  PDO::FETCH_CLASS,
  Pasatiempo::class
 );
 return recibeFetchAll($resultado);
}
