<?php

namespace srv\modelo;

require_once
 "lib/php/validaNombreNoVacio.php";
require_once
 "lib/php/validaUuidNoVacio.php";

class Pasatiempo
{
 public string $uuid;
 public string $nombre;
 public int $modificacion;
 public int $eliminado;

 public function valida()
 {
  validaUuidNoVacio($this->uuid);
  validaNombreNoVacio(
   $this->nombre
  );
 }
}
