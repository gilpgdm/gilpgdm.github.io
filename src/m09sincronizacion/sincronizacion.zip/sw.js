/* Este archivo debe estar
 * colocado en la carpeta raíz del
 * sitio.
 * 
 * Cualquier cambio en el
 * contenido de este archivo hace
 * que el service worker se
 * reinstale.
 * 
 * Normalmente se cambia el número
 * de la versión cuando cambia el
 * contenido de los archivos. */
const VERSION = "1.00"

/** Nombre del archivo de cache. */
const CACHE = "sincro"

/**
 * Archivos requeridos para que la
 * aplicación funcione fuera de
 * línea.
 */
const ARCHIVOS = [
 "agrega.html",
 "index.html",
 "modifica.html",
 "js/configura.js",
 "js/dao/conn.js",
 "js/dao/pasatiempoAgrega.js",
 "js/dao/pasatiempoBusca.js",
 "js/dao/pasatiempoConsultaNoEliminados.js",
 "js/dao/pasatiempoConsultaTodos.js",
 "js/dao/pasatiempoElimina.js",
 "js/dao/pasatiempoModifica.js",
 "js/dao/pasatiempoValida.js",
 "js/dao/pasatiempoValidaNuevo.js",
 "js/dao/reemplazaObjetos.js",
 "js/txt/txtPasatiempoNoEncontrado.js",
 "lib/js/bdConsulta.js",
 "lib/js/bdEjecuta.js",
 "lib/js/confirmaEliminar.js",
 "lib/js/ejecuta.js",
 "lib/js/enviaJson.js",
 "lib/js/escuchaEventosAgrega.js",
 "lib/js/escuchaEventosModifica.js",
 "lib/js/htmlentities.js",
 "lib/js/MetodoHttp.js",
 "lib/js/muestraError.js",
 "lib/js/muestraRender.js",
 "lib/js/muestraTexto.js",
 "lib/js/parametrosDePagina.js",
 "lib/js/registraServiceWorkerSiEsSoportado.js",
 "lib/js/saltaAIndex.js",
 "lib/js/valida.js",
 "lib/js/validaNombreNoVacio.js",
 "lib/js/validaTextoNoVacio.js",
 "lib/js/validaUuidNoVacio.js",
 "lib/js/custom/boton-agregar.js",
 "lib/js/custom/boton-eliminar.js",
 "lib/js/custom/boton-guardar.js",
 "lib/js/custom/campo-nombre-cargando.js",
 "lib/js/custom/campo-nombre.js",
 "lib/js/custom/hipervinculo-agregar-agrega.js",
 "lib/js/custom/hipervinculo-cancelar-index.js",
 "lib/js/custom/indica-campos-obligatorios.js",
 "lib/js/custom/indicador-cargando.js",
 "lib/js/custom/lista-principal.js",
 "lib/js/plantilla/plantillaNoEsArray.js",
 "lib/js/plantilla/plantillaNoEsTexto.js",
 "lib/js/txt/txtConfirmaEliminar.js",
 "lib/js/txt/txtFaltaElNombre.js",
 "lib/js/txt/txtFaltaElUuid.js",
 "lib/js/txt/txtRegistrado.js",
 "/"
]

if (self instanceof
 ServiceWorkerGlobalScope) {
 // Evento al empezar a instalar
 self.addEventListener("install",
  instala)

 /* Evento al solicitar información
  * a la red */
 self.addEventListener("fetch",
  descargaDatosDeLaRed)

 // Evento cuando está activo.
 self.addEventListener("activate",
  activo)
}

function activo() {
 console.log(
  "Service Worker activo.")
}

/** @param {ExtendableEvent} evt */
function instala(evt) {
 console.log(
  "Service Worker instalando.")
 evt.waitUntil(llenaElCache())
}

/** @param {FetchEvent} evt */
function descargaDatosDeLaRed(
 evt) {
 if (
  evt.request.method === "GET") {
  evt.respondWith(
   buscaEnElCache(evt))
 }
}

async function llenaElCache() {
 console.log(
  "Intentando cargar cache:",
  CACHE)
 await borraTodosLosCaches()
 await cargaElListadoDeARCHIVOS()
 console.
  log("Cache cargado:", CACHE)
 console.log("Versión:", VERSION)
}

async function
 borraTodosLosCaches() {
 const keys = await caches.keys()
 for (const key of keys) {
  await caches.delete(key)
 }
}

async function
 cargaElListadoDeARCHIVOS() {
 const cache = await abreElCache()
 await cache.addAll(ARCHIVOS)
}

function abreElCache() {
 return caches.open(CACHE)
}

/** @param {FetchEvent} evt */
async function buscaEnElCache(
 evt) {
 // Busca el contenido del cache.
 const cache = await abreElCache()
 const request = evt.request
 const response =
  await buscaLaPeticionEnElCache(
   cache, request)
 if (response === undefined) {
  /* Si no lo encuentra, lo
   * empieza a descargar de la red
   * y devuelve la promesa. */
  return fetch(request)
 } else {
  /* Si lo encuentra, devuelve la
   * respuesta que encontró en el
   * cache. */
  return response
 }
}

/**
 * @param {Cache} cache
 * @param {Request} request
 */
function buscaLaPeticionEnElCache(
 cache, request) {
 /* Al buscar no toma en cuenta la
  * parte después del símbolo ? en
  * la URL. */
 return cache.match(request,
  { ignoreSearch: true })
}