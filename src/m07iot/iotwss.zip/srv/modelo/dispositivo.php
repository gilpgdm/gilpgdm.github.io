<?php

namespace srv\modelo;

require_once
 "lib/php/validaIdNoVacio.php";
require_once
 "lib/php/validaTextoNoVacio.php";
require_once
 "srv/txt/txtFaltaElValor.php";

class Dispositivo
{

 public string $id;
 public string $valor;

 public function valida()
 {
  validaIdNoVacio($this->id);
  $this->validaValorNoVacio();
 }

 function validaValorNoVacio()
 {
  validaTextoNoVacio(
   $this->valor,
   txtFaltaElValor()
  );
 }
}
