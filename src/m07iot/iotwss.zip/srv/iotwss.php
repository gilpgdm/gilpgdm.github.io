<?php

namespace srv;

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once "srv/dao/guarda.php";

use
 Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

class IotWss implements
 MessageComponentInterface
{
 private $valor;
 protected $clientes;

 public function __construct(
  $valor
 ) {
  $this->valor = $valor;
  $this->clientes =
   new \SplObjectStorage;
 }

 public function onOpen(
  ConnectionInterface $con
 ) {
  $this->clientes->attach($con);
  $con->send($this->valor);
  echo "Conectado: " .
   $con->resourceId . "\n";
 }

 public function onMessage(
  ConnectionInterface $from,
  $msg
 ) {
  echo "Recibido: $msg\n";
  $this->valor =
   $this->valor === "0"
   ? "1" : "0";
  guarda($this->valor);
  foreach ($this->clientes
   as $client) {
   $client->send($this->valor);
  }
 }

 public function onClose(
  ConnectionInterface $con
 ) {
  $this->clientes->detach($con);
  echo "Desconectado: " .
   $con->resourceId . "\n";
 }

 public function onError(
  ConnectionInterface $con,
  \Exception $e
 ) {
  echo "Error: " .
   $e->getMessage() . "\n";
  $con->close();
 }
}
