<?php

use srv\dao\AccesoBd;
use srv\modelo\Dispositivo;

function dispositivoAgrega(
 Dispositivo $dispositivo
) {
 $dispositivo->valida();
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "INSERT INTO DISPOSITIVO
    (DIS_ID, DIS_VALOR)
   VALUES
    (:id, :valor)"
 );
 $stmt->execute([
  ":id" => $dispositivo->id,
  ":valor" => $dispositivo->valor
 ]);
}
