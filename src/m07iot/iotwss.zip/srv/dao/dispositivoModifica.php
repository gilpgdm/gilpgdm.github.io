<?php

use srv\dao\AccesoBd;
use srv\modelo\Dispositivo;

function dispositivoModifica(
 Dispositivo $dispositivo
) {
 $dispositivo->valida();
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "UPDATE DISPOSITIVO
   SET DIS_VALOR = :valor
   WHERE DIS_ID = :id"
 );
 $stmt->execute([
  ":id" => $dispositivo->id,
  ":valor" => $dispositivo->valor
 ]);
}
