<?php


use srv\dao\AccesoBd;
use srv\modelo\Dispositivo;

function dispositivoBusca($id)
{
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "SELECT
     DIS_ID as id,
     DIS_VALOR as valor
   FROM DISPOSITIVO
   WHERE DIS_ID = :id"
 );
 $stmt->execute([
  ":id" => $id
 ]);
 $stmt->setFetchMode(
  PDO::FETCH_CLASS,
  Dispositivo::class
 );
 return $stmt->fetch();
}
