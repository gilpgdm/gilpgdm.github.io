/* Este archivo debe estar
 * colocado en la carpeta raíz del
 * sitio.
 * 
 * Cualquier cambio en el
 * contenido de este archivo hace
 * que el service worker se
 * reinstale.
 * 
 * Normalmente se cambia el número
 * de la versión cuando cambia el
 * contenido de los archivos. */
const VERSION = "1.00"

/** Nombre del archivo de cache. */
const CACHE = "pwamd"

/**
 * Archivos requeridos para que la
 * aplicación funcione fuera de
 * línea.
 */
const ARCHIVOS = [
 "ayuda.html",
 "botones.html",
 "campos.html",
 "favicon.ico",
 "formulario.html",
 "iconos.html",
 "index.html",
 "listas.html",
 "navbar.html",
 "navtab.html",
 "navTabFixed.html",
 "secundaria.html",
 "segmentado.html",
 "select.html",
 "site.webmanifest",
 "slider.html",
 "tarjetas.html",
 "css/estilos.css",
 "img/Escultura_de_coyote.jpeg",
 "img/icono2048.png",
 "img/maskable_icon.png",
 "img/maskable_icon_x128.png",
 "img/maskable_icon_x192.png",
 "img/maskable_icon_x384.png",
 "img/maskable_icon_x48.png",
 "img/maskable_icon_x512.png",
 "img/maskable_icon_x72.png",
 "img/maskable_icon_x96.png",
 "img/pexels-craig-dennis-3701822.jpg",
 "img/pexels-creative-workshop-3978352.jpg",
 "img/pexels-erik-karits-3732453.jpg",
 "img/pexels-esteban-arango-10226903.jpg",
 "img/pexels-moises-patrício-10961948.jpg",
 "img/pexels-ralph-2270848.jpg",
 "img/pexels-rasmus-svinding-35435.jpg",
 "img/pexels-steve-397857.jpg",
 "img/pexels-vadim-b-141496.jpg",
 "js/configura.js",
 "js/nav-bar.js",
 "js/nav-drw.js",
 "js/nav-tab-fixed.js",
 "js/nav-tab-scrollable.js",
 "lib/css/cards.css",
 "lib/css/filled.css",
 "lib/css/icon.css",
 "lib/css/list.css",
 "lib/css/material-symbols-outlined.css",
 "lib/css/md3.css",
 "lib/css/navBar.css",
 "lib/css/navDrw.css",
 "lib/css/navTab.css",
 "lib/css/outline.css",
 "lib/css/roboto.css",
 "lib/css/segmented.css",
 "lib/css/slider.css",
 "lib/fonts/MaterialSymbolsOutlined[FILL,GRAD,opsz,wght].codepoints",
 "lib/fonts/MaterialSymbolsOutlined[FILL,GRAD,opsz,wght].ttf",
 "lib/fonts/MaterialSymbolsOutlined[FILL,GRAD,opsz,wght].woff2",
 "lib/fonts/roboto-v30-latin-regular.ttf",
 "lib/fonts/roboto-v30-latin-regular.woff2",
 "lib/js/constantes.js",
 "lib/js/getAttribute.js",
 "lib/js/md3.js",
 "lib/js/msg.js",
 "lib/js/muestraError.js",
 "lib/js/registraServiceWorkerSiEsSoportado.js",
 "lib/js/setBooleanAttribute.js",
 "lib/js/custom/center-aligned-top-app-bar.js",
 "lib/js/custom/menu-option.js",
 "lib/js/custom/overflow-menu.js",
 "lib/js/custom/select-menu.js",
 "lib/js/custom/slider-field.js",
 "lib/js/custom/text-field.js",
 "lib/js/custom/top-app-bar.js",
 "lib/js/txt/txtObligatorio.js",
 "lib/js/txt/txtRegistrado.js",
 "/"
]

if (self instanceof
 ServiceWorkerGlobalScope) {
 // Evento al empezar a instalar
 self.addEventListener("install",
  instala)

 /* Evento al solicitar información
  * a la red */
 self.addEventListener("fetch",
  descargaDatosDeLaRed)

 // Evento cuando está activo.
 self.addEventListener("activate",
  activo)
}

function activo() {
 console.log(
  "Service Worker activo.")
}

/** @param {ExtendableEvent} evt */
function instala(evt) {
 console.log(
  "Service Worker instalando.")
 evt.waitUntil(llenaElCache())
}

/** @param {FetchEvent} evt */
function descargaDatosDeLaRed(
 evt) {
 if (
  evt.request.method === "GET") {
  evt.respondWith(
   buscaEnElCache(evt))
 }
}

async function llenaElCache() {
 console.log(
  "Intentando cargar cache:",
  CACHE)
 await borraTodosLosCaches()
 await cargaElListadoDeARCHIVOS()
 console.
  log("Cache cargado:", CACHE)
 console.log("Versión:", VERSION)
}

async function
 borraTodosLosCaches() {
 const keys = await caches.keys()
 for (const key of keys) {
  await caches.delete(key)
 }
}

async function
 cargaElListadoDeARCHIVOS() {
 const cache = await abreElCache()
 await cache.addAll(ARCHIVOS)
}

function abreElCache() {
 return caches.open(CACHE)
}

/** @param {FetchEvent} evt */
async function buscaEnElCache(
 evt) {
 // Busca el contenido del cache.
 const cache = await abreElCache()
 const request = evt.request
 const response =
  await buscaLaPeticionEnElCache(
   cache, request)
 if (response === undefined) {
  /* Si no lo encuentra, lo
   * empieza a descargar de la red
   * y devuelve la promesa. */
  return fetch(request)
 } else {
  /* Si lo encuentra, devuelve la
   * respuesta que encontró en el
   * cache. */
  return response
 }
}

/**
 * @param {Cache} cache
 * @param {Request} request
 */
function buscaLaPeticionEnElCache(
 cache, request) {
 /* Al buscar no toma en cuenta la
  * parte después del símbolo ? en
  * la URL. */
 return cache.match(request,
  { ignoreSearch: true })
}