export class NavTabFixed
 extends HTMLElement {

 connectedCallback() {
  this.classList
   .add("navTab", "fixed")

  this.innerHTML = /* html */
   `<a id="aIndex"
      href="index.html">
     <span
 class="material-symbols-outlined">
      home
     </span>
     Inicio
    </a>

    <a id="aNavTab"
      href="navtab.html">
     <span
class="material-symbols-outlined">
      swipe_left
     </span>
     Pestañas scrollable
    </a>

    <a id="aNavTabFixed"
      href="navTabFixed.html">
     <span
class="material-symbols-outlined">
      tabs
     </span>
     Pestañas fijas
    </a>

    <a id="aNavBar"
      href="navbar.html">
     <span
class="material-symbols-outlined">
      bottom_navigation
     </span>
     Barra de navegación
    </a>

    <a id="aAyuda"
      href="ayuda.html">
     <span
 class="material-symbols-outlined">
      help
     </span>
     Ayuda
    </a>`

 }

}

customElements.define(
 "nav-tab-fixed", NavTabFixed)