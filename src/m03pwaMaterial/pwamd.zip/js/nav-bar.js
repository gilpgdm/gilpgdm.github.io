export class NavBar
 extends HTMLElement {

 connectedCallback() {
  this.classList.add("navBar")

  this.innerHTML = /* html */
   `<a id="aIndex"
      href="index.html">
     <span
 class="material-symbols-outlined">
      home
     </span>
     Inicio
    </a>

    <a id="aNavTabFixed"
      href="navTabFixed.html">
     <span
class="material-symbols-outlined">
      tabs
     </span>
     Pestañas fijas
    </a>

    <a id="aNavBar"
      href="navbar.html">
     <span
class="material-symbols-outlined">
      bottom_navigation
     </span>
     Barra de navegación
    </a>

    <a id="aFormulario"
      href="formulario.html">
     <span
class="material-symbols-outlined">
      newspaper
     </span>
     Formulario
    </a>`

 }

}

customElements.define(
 "nav-bar", NavBar)