<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeJson.php";
require_once __DIR__ . "/modelo/Suscripcion.php";
require_once __DIR__ . "/modelo/leeSuscripcion.php";
require_once __DIR__ . "/dao/suscripcionAgrega.php";
require_once __DIR__ . "/dao/suscripcionBusca.php";
require_once __DIR__ . "/dao/suscripcionModifica.php";
require_once __DIR__ . "/dao/suscripcionElimina.php";

ejecuta(function () {

 $json = leeJson();

 $modelo = leeSuscripcion($json);

 $metodoHttp = $_SERVER["REQUEST_METHOD"];

 if ($metodoHttp === "POST") {
  suscripcionAgrega($modelo);
 } elseif ($metodoHttp === "PUT") {
  $registrado = suscripcionBusca($modelo->endpoint);
  if ($registrado) {
   suscripcionModifica($modelo);
  } else {
   suscripcionAgrega($modelo);
  }
 } elseif ($metodoHttp === "DELETE") {
  suscripcionElimina($modelo->endpoint);
 }

 return [];
});
