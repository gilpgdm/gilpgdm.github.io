<?php

require_once __DIR__ . "/../../vendor/autoload.php";

use Minishlink\WebPush\SubscriptionInterface;

class Suscripcion implements SubscriptionInterface
{

 public string $endpoint;
 public string $publicKey;
 public string $authToken;
 public string $contentEncoding;

 public function __construct(
  string $endpoint = "",
  string $publicKey = "",
  string $authToken = "",
  string $contentEncoding = ""
 ) {
  $this->endpoint = $endpoint;
  $this->publicKey = $publicKey;
  $this->authToken = $authToken;
  $this->contentEncoding = $contentEncoding;
 }

 public function getEndpoint(): string
 {
  return $this->endpoint;
 }

 public function getPublicKey(): ?string
 {
  return $this->publicKey;
 }

 public function getAuthToken(): ?string
 {
  return $this->authToken;
 }

 public function getContentEncoding(): ?string
 {
  return $this->contentEncoding;
 }
}
