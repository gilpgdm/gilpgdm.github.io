<?php

require_once __DIR__ . "/Suscripcion.php";

function leeSuscripcion($objeto)
{

 if (!isset($objeto->endpoint) || !is_string($objeto->endpoint))
  throw new Exception("El endpoint debe ser texto.");

 if (!isset($objeto->publicKey)  || !is_string($objeto->publicKey))
  throw new Exception("El publicKey debe ser texto.");

 if (!isset($objeto->authToken) || !is_string($objeto->authToken))
  throw new Exception("El authToken debe ser texto.");

 if (!isset($objeto->contentEncoding) || !is_string($objeto->contentEncoding))
  throw new Exception("El contentEncoding debe ser texto.");

 return new Suscripcion(
  endpoint: $objeto->endpoint,
  publicKey: $objeto->publicKey,
  authToken: $objeto->authToken,
  contentEncoding: $objeto->contentEncoding
 );
}
