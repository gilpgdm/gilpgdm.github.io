<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require __DIR__ .
 "/../vendor/autoload.php";
require_once
 "srv/dao/suscripcionConsulta.php";
require_once
 "srv/dao/suscripcionElimina.php";

use lib\php\Servicio;
use Minishlink\WebPush\MessageSentReport;
use Minishlink\WebPush\WebPush;

class SrvNotifica extends Servicio
{

 const AUTH = [
  "VAPID" => [
   "subject"
   => "https://notificacionesphp.gilbertopachec2.repl.co/",
   "publicKey"
   => "BMBlr6YznhYMX3NgcWIDRxZXs0sh7tCv7_YCsWcww0ZCv9WGg-tRCXfMEHTiBPCksSqeve1twlbmVAZFv7GSuj0",
   "privateKey"
   => "vplfkITvu0cwHqzK9Kj-DYStbCH_9AhGx9LqMyaeI6w"
  ]
 ];

 protected
 function implementacion()
 {
  $webPush =
   new WebPush(self::AUTH);

  $mensaje = "Hola! 👋";

  $reportes =
   $this->enviaMensajeATodasLasSuscripciones(
    $webPush,
    $mensaje
   );
  $reporteDeEnvios =
   $this->generaReporteDeEnvioACadaSuscripcion(
    $reportes
   );
  return $reporteDeEnvios;
 }

 private function
 enviaMensajeATodasLasSuscripciones(
  WebPush $webPush,
  string $mensaje
 ) {
  $suscripciones =
   suscripcionConsulta();
  foreach ($suscripciones
   as $suscripcion) {
   $webPush->queueNotification(
    $suscripcion,
    $mensaje
   );
  }
  $reportes = $webPush->flush();
  return $reportes;
 }

 /**
  * @param Generator<array-key,
  *  MessageSentReport> $reportes
  */
 private function
 generaReporteDeEnvioACadaSuscripcion(
  Generator $reportes
 ) {
  $reporteDeEnvios = [];
  foreach ($reportes as $reporte) {
   if ($reporte->isSuccess()) {
    $reporteDeEnvios[] =
     $this->reporteDeExito(
      $reporte
     );
   } else {
    $this
     ->eliminaSuscripcionSiYaExpiro(
      $reporte
     );
    $reporteDeEnvios[] =
     $this->reporteDeFallo(
      $reporte
     );
   }
  }
  return $reporteDeEnvios;
 }

 private function
 reporteDeExito(
  MessageSentReport $reporte
 ) {
  $endpoint =
   $this->getEndpoint($reporte);
  return [
   "endpoint" => $endpoint,
   "resultado" => "Éxito"
  ];
 }

 private function
 getEndpoint(
  MessageSentReport $reporte
 ) {
  $endpoint = $reporte
   ->getRequest()->getUri()
   ->__toString();
  return $endpoint;
 }

 private function
 eliminaSuscripcionSiYaExpiro(
  MessageSentReport $reporte
 ) {
  if ($reporte
   ->isSubscriptionExpired()
  ) {
   $endpoint =
    $this->getEndpoint($reporte);
   suscripcionElimina($endpoint);
  }
 }

 private function
 reporteDeFallo(
  MessageSentReport $reporte
 ) {
  $endpoint =
   $this->getEndpoint($reporte);
  return [
   "endpoint" => $endpoint,
   "resultado" => "Fallo",
   "explicacion" =>
   $reporte->getReason()
  ];
 }
}

$servicio = new SrvNotifica();
$servicio->ejecuta();
