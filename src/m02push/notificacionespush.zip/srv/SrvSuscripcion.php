<?php

require __DIR__ .
 "/../vendor/autoload.php";
require __DIR__ .
 "/../vendor/autoload.php";
require_once
 "srv/dao/suscripcionAgrega.php";
require_once
 "srv/dao/suscripcionBusca.php";
require_once
 "srv/dao/suscripcionModifica.php";
require_once
 "srv/dao/suscripcionElimina.php";
require_once "lib/php/leeJson.php";
require_once
 "lib/php/copiaCampos.php";

use lib\php\Servicio;
use srv\modelo\Suscripcion;

class SrvSuscripcion
extends Servicio
{

 protected
 function implementacion()
 {
  $modelo =
   $this->leeSuscripcion();
  $metodoHttp =
   $_SERVER["REQUEST_METHOD"];

  if ($metodoHttp === "POST") {
   suscripcionAgrega($modelo);
  } elseif ($metodoHttp === "PUT") {
   $registrado = suscripcionBusca(
    $modelo->endpoint
   );
   if ($registrado) {
    suscripcionModifica($modelo);
   } else {
    suscripcionAgrega($modelo);
   }
  } elseif (
   $metodoHttp === "DELETE"
  ) {
   suscripcionElimina(
    $modelo->endpoint
   );
  }
  return [];
 }

 function leeSuscripcion()
 {
  $json = leeJson();
  $modelo = new Suscripcion();
  copiaCampos($modelo, $json);
  return $modelo;
 }
}

$servicio = new SrvSuscripcion();
$servicio->ejecuta();
