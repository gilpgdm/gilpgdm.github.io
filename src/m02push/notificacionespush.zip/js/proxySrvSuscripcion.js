import {
 MetodoHttp
} from "../lib/js/MetodoHttp.js"
import {
 enviaJson
} from "../lib/js/enviaJson.js"
import {
 getSuscripcionDto
} from "../lib/js/getSuscripcionDto.js"

/**
 * Actua como representante
 * del servicio SrvSuscripcion.
 * Si quieres usarlo, debes usar
 * esta función.
 * Proxy significa representante o
 * apoderado.
 * 
 * @param {PushSubscription
 *                   } suscripcion
 * @param {MetodoHttp} metodoHttp
 */
export async function
 proxySrvSuscripcion(suscripcion,
  metodoHttp) {
 const dto =
  getSuscripcionDto(suscripcion)
 await enviaJson(dto, metodoHttp,
  "srv/SrvSuscripcion.php")
}
