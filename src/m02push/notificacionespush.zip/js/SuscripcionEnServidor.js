import {
 MetodoHttp
} from "../lib/js/MetodoHttp.js"
import {
 proxySrvSuscripcion
} from "./proxySrvSuscripcion.js"

export class
 SuscripcionEnServidor {

 /**
  * @param {PushSubscription
  *                  } suscripcion
  */
 static async agrega(suscripcion) {
  await proxySrvSuscripcion(
   suscripcion, MetodoHttp.POST)
 }

 /**
  * @param {PushSubscription
  *                  } suscripcion
  */
 static async modifica(
  suscripcion) {
  await proxySrvSuscripcion(
   suscripcion, MetodoHttp.PUT)
 }

 /**
  * @param {PushSubscription
  *                  } suscripcion
  */
 static async elimina(suscripcion) {
  await proxySrvSuscripcion(
   suscripcion, MetodoHttp.DELETE)
 }
}