escuchaNotificacionesPush()

function
 escuchaNotificacionesPush() {
 if (self instanceof
  ServiceWorkerGlobalScope) {
  self.addEventListener("push",
   notificacionPushRecibida)
 }
}

/** @param {PushEvent} evt */
async function
 notificacionPushRecibida(evt) {
 const notificacion = evt.data
 if (notificacion !== null
  && notificacionesPermitidas()) {
  evt.waitUntil(
   muestraNotificacion(
    notificacion)
  )
 }
}

function
 notificacionesPermitidas() {
 return self.Notification
  .permission === 'granted'
}

/**
 * @param {PushMessageData
 *                  } notificacion
 */
async function
 muestraNotificacion(
  notificacion) {
 if (self instanceof
  ServiceWorkerGlobalScope) {
  const mensaje =
   notificacion.text()
  await self.registration.
   showNotification(mensaje)
 }
}