<?php
require __DIR__ .
 "/../vendor/autoload.php";
require_once __DIR__ .
 "/modelo/Suscripcion.php";
require_once __DIR__ .
 "/dao/suscripcionConsulta.php";
require_once __DIR__ .
 "/dao/suscripcionElimina.php";
require_once __DIR__ .
 "/../lib/php/Servicio.php";

use Minishlink\WebPush\WebPush;

class SrvNotifica extends Servicio
{
 protected
 function implementacion()
 {
  $suscripciones =
   suscripcionConsulta();

  $auth = [
   "VAPID" => [
    "subject" =>
    "https://phppush--gilbertopacheco.repl.co/",
    "publicKey" =>
    "BMBlr6YznhYMX3NgcWIDRxZXs0sh7tCv7_YCsWcww0ZCv9WGg-tRCXfMEHTiBPCksSqeve1twlbmVAZFv7GSuj0",
    "privateKey" =>
    "vplfkITvu0cwHqzK9Kj-DYStbCH_9AhGx9LqMyaeI6w"
   ]
  ];

  $webPush = new WebPush($auth);

  foreach ($suscripciones
   as $suscripcion) {
   $webPush->queueNotification(
    $suscripcion,
    "Hola! 👋"
   );
  }
  $reportes = $webPush->flush();
  $resultados = [];
  foreach ($reportes as $reporte) {
   $endpoint = $reporte
    ->getRequest()->getUri()
    ->__toString();
   if ($reporte->isSuccess()) {
    $resultados[] = [
     "endpoint" => $endpoint,
     "resultado" => "Éxito"
    ];
   } else {
    if ($reporte
     ->isSubscriptionExpired()
    ) {
     suscripcionElimina($endpoint);
    }
    $resultados[] = [
     "endpoint" => $endpoint,
     "resultado" => "Fallo",
     "explicacion" =>
     $reporte->getReason()
    ];
   }
  }
  return $resultados;
 }
}
$servicio = new SrvNotifica();
$servicio->ejecuta();
