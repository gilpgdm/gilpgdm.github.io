#ifndef __PROXY_AGREGA_ENTRADA_H__
#define __PROXY_AGREGA_ENTRADA_H__

String
proxyAgregaEntrada(
  const char* huellaDigital,
  const char * dispostivo,
  int valor);
#endif
