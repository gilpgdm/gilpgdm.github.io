#include <ESP8266WiFi.h>
#include <ESP8266WiFiMulti.h>
#include <WiFiUdp.h>
#include "util.hpp"

ESP8266WiFiMulti WiFiMulti;

void conectaWiFi(const char *ssid,
                 const char *pass) {
  for (uint8_t t = 4; t > 0;
       t--) {
    Serial.printf(
      "ESPERANDO %d...\n", t);
    Serial.flush();
    delay(1000);
  }
  Serial.println(
    "Conectando WiFi...");
  WiFi.mode(WIFI_STA);
  WiFiMulti.addAP(ssid, pass);
}