#ifndef __UTIL_H__
#define __UTIL_H__

const char* const URL_ENTRADA = "https://iot.gilbertopachec1.repl.co/entrada/";
const char* const URL_SALIDA = "https://iot.gilbertopachec1.repl.co/salida/";

void conectaWiFi(const char *ssid,
                 const char *pass);
#endif
