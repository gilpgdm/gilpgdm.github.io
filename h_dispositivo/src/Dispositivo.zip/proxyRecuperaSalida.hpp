#ifndef __PROXY_REC_SALIDA_H__
#define __PROXY_REC_SALIDA_H__

#include "ResInt.hpp"

ResInt proxyRecuperaSalida(
  const char *huellaDigital,
  const char * dispostivo);
#endif
