/**
 * @param {string} id
 */
export function validaId(id) {
  if (id === "")
   throw new Error("Falta el id.")
 }