/**
 * @param {string} nombre
 */
export function validaNombre(nombre) {
 if (nombre === "")
  throw new Error("Falta el nombre.")
}