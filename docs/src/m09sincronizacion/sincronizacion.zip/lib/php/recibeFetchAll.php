<?php

function recibeFetchAll(false|array $resultado)
{
 if ($resultado === false) {
  return [];
 } else {
  return $resultado;
 }
}
