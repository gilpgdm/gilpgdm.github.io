/* Ejemplo de render en el cliente. No se usa import
 * porque Firefox no lo soporta en los web workers. */

// Verifica si el código corre dentro de un web worker.
if (self instanceof WorkerGlobalScope) {

 // Se invoca al recibir un mensaje de la página.
 onmessage = event => {

  /**
   * @type {  {
   *   uuid: string,
   *   nombre: string,
   *   modificacion: number,
   *   eliminado: boolean,
   *  } [] }
   */
  const pasatiempos = event.data

  let render = ""
  for (const modelo of pasatiempos) {
   const nombre = htmlentities(modelo.nombre)
   const searchParams = new URLSearchParams([["uuid", modelo.uuid]])
   const params = htmlentities(searchParams.toString())
   render += /* html */
    `<li>
      <p><a href="modifica.html?${params}">${nombre}</a></p>
     </li>`
  }

  // Envía el render a la página que invocó este web worker.
  self.postMessage(render)

 }

}

/**
 * Codifica un texto para que cambie los caracteres
 * especiales y no se pueda interpretar como
 * etiiqueta HTML. Esta técnica evita la inyección
 * de código.
 * @param { string } texto
 * @returns { string } un texto que no puede
 *  interpretarse como HTML. */
export function htmlentities(texto) {
 return texto.replace(/[<>"']/g, textoDetectado => {
  switch (textoDetectado) {
   case "<": return "&lt;"
   case ">": return "&gt;"
   case '"': return "&quot;"
   case "'": return "&#039;"
   default: return textoDetectado
  }
 })
}