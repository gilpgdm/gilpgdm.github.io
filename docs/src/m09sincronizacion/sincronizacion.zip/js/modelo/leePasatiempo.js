import { Pasatiempo } from "./Pasatiempo.js"
import {
 validaQueTengaLasPropiedadesDePasatiempo
} from "./validaQueTengaLasPropiedadesDePasatiempo.js"

/** @param { any } objeto */
export function leePasatiempo(objeto) {
 const validado = validaQueTengaLasPropiedadesDePasatiempo(objeto)
 return new Pasatiempo({
  uuid: validado.uuid,
  nombre: validado.nombre,
  modificacion: validado.modificacion,
  eliminado: validado.eliminado,
 })
}