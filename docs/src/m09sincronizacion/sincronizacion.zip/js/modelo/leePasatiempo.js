import {
 Pasatiempo
} from "./Pasatiempo.js"

/** @param {any} objeto */
export function leePasatiempo(
 objeto) {
 const nombre = objeto.nombre
 if (typeof nombre !== "string")
  throw new Error(
   "El nombre debe ser texto.")
 const uuid = objeto.uuid
 if (typeof uuid !== "string")
  throw new Error(
   "El uuid debe ser texto.")
 const eliminado = objeto.eliminado
 if (typeof eliminado
  !== "boolean")
  throw new Error("El campo "
   + "eliminado debe ser "
   + "booleano.")
 const modificacion =
  objeto.modificacion
 if (typeof modificacion
  !== "number")
  throw new Error("El campo "
   + "modificacion debe ser "
   + "número.")
 return new Pasatiempo(nombre,
  uuid, modificacion, eliminado)
}