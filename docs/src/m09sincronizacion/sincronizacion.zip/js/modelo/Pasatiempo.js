export class Pasatiempo {

 /**
  * @param {string} nombre
  * @param {string} uuid
  * @param {number} modificacion
  * @param {boolean} eliminado
  */
 constructor(nombre = "",
  uuid = "", modificacion = NaN,
  eliminado = true) {
  this.nombre = nombre
  this.uuid = uuid
  this.modificacion = modificacion
  this.eliminado = eliminado
 }

 validaNuevo() {
  if (this.nombre === "")
   throw new Error(
    "Falta el nombre.")
 }

 valida() {
  if (this.uuid === "")
   throw new Error(
    "Falta el uuid.")
  if (this.nombre === "")
   throw new Error(
    "Falta el nombre.")
 }

}