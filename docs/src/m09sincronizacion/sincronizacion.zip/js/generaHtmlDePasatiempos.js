import {
 htmlentities
} from "../lib/js/htmlentities.js"
import {
 Pasatiempo
} from "./modelo/Pasatiempo.js"

/**
 * @param {Pasatiempo[]
 *                  } pasatiempos
 */
export function
 generaHtmlDePasatiempos(
  pasatiempos) {
 let render = ""
 for (const modelo
  of pasatiempos) {
  const nombre =
   htmlentities(modelo.nombre)
  const searchParams =
   new URLSearchParams(
    [["uuid", modelo.uuid]])
  const params = htmlentities(
   searchParams.toString())
  render += /* HTML */
   `<li>
      <p>
<a href="modifica.html?${params}">
 ${nombre}</a>
      </p>
     </li>`
 }
 return render
}
