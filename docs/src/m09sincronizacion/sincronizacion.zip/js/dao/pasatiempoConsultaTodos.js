import { bdConsulta } from "../../lib/js/bdConsulta.js"
import { NOMBRE_DEL_ALMACEN_PASATIEMPO, accesoBd } from "./accesoBd.js"

/**
 * Lista todos los objetos, incluyendo los que tienen
 * borrado lógico.
 */
export async function pasatiempoConsultaTodos() {

 return bdConsulta(accesoBd, [NOMBRE_DEL_ALMACEN_PASATIEMPO],
  /**
   * @param { IDBTransaction } transaccion 
   * @param { (result: any[]) => any } resolve 
  */
  (transaccion, resolve) => {

   const resultado = []

   /* Pide un cursor para recorrer cada uno de los
    * registristros que devuelve la consulta. */
   const consulta =
    transaccion.objectStore(NOMBRE_DEL_ALMACEN_PASATIEMPO).openCursor()

   /* onsuccess se invoca por cada uno de los registros de la
   * consulta y una vez cuando se acaban dichos registros. */
   consulta.onsuccess = () => {

    /* El cursor que corresponde al registro se recupera usando
     *  consulta.result */
    const cursor = consulta.result

    if (cursor === null) {

     /* Si el cursor es igual a null, ya no hay más registros que
      * procesar; por lo mismo, se devuelve el resultado con los
      * pasatiempos recuperados, usando
      *  resolve(resultado). */
     resolve(resultado)

    } else {

     /* Si el cursor es diferente a null, si hay más registros.
      * El registro que sigue se obtiene con
      *  cursor.value*/
     resultado.push(cursor.value)

     /* Busca el siguiente registro de la consulta, que se obtiene
      * la siguiente vez que se invoque la función
      *  onsuccess. */
     cursor.continue()

    }

   }

  })

}