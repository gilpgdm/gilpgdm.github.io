import {
 bdEjecuta
} from "../../lib/js/bdEjecuta.js"
import {
 Pasatiempo
} from "../modelo/Pasatiempo.js"
import {
 accesoBd, ALMACEN_PASATIEMPO
} from "./accesoBd.js"

let secuencia = 0

/** @param {Pasatiempo} modelo */
export async function
 pasatiempoAgrega(modelo) {
 modelo.validaNuevo()
 modelo.modificacion = Date.now()
 modelo.eliminado = false
 // Genera uuid único en internet.
 modelo.uuid =
  Date.now().toString()
  + Math.random()
  + secuencia
 secuencia++

 return bdEjecuta(accesoBd,
  [ALMACEN_PASATIEMPO],
  transaccion => {
   const almacenPasatiempo =
    transaccion.objectStore(
     ALMACEN_PASATIEMPO)
   almacenPasatiempo.add(modelo)
  })
}