import { bdEjecuta } from "../../lib/js/bdEjecuta.js"
import { accesoBd, NOMBRE_DEL_ALMACEN_PASATIEMPO } from "./accesoBd.js"

/**
 * Borra el contenido del almacén pasatiempo y guarda el
 * contenido del listado.
 * @param {any[]} datosNuevos
 */
export async function pasatiemposReemplaza(datosNuevos) {
 return bdEjecuta(accesoBd, [NOMBRE_DEL_ALMACEN_PASATIEMPO],
  transaccion => {
   const almacenPasatiempo =
    transaccion.objectStore(NOMBRE_DEL_ALMACEN_PASATIEMPO)
   almacenPasatiempo.clear()
   for (const objeto of datosNuevos) {
    almacenPasatiempo.add(objeto)
   }
  })
}