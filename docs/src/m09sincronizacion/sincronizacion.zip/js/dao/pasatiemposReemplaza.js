import {
 bdEjecuta
} from "../../lib/js/bdEjecuta.js"
import {
 accesoBd, ALMACEN_PASATIEMPO
} from "./accesoBd.js"

/**
 * Borra el contenido del almacén y
 * guarda el contenido del listado.
 * @param {any[]} datosNuevos
 */
export async function
 pasatiemposReemplaza(
  datosNuevos) {
 return bdEjecuta(accesoBd,
  [ALMACEN_PASATIEMPO],
  transaccion => {
   const almacenPasatiempo =
    transaccion.objectStore(
     ALMACEN_PASATIEMPO)
   almacenPasatiempo.clear()
   for (const objeto
    of datosNuevos) {
    almacenPasatiempo.add(objeto)
   }
  })
}