import { bdConsulta } from "../../lib/js/bdConsulta.js"
import { leePasatiempo } from "../modelo/leePasatiempo.js"
import { Pasatiempo } from "../modelo/Pasatiempo.js"
import { accesoBd, NOMBRE_DEL_ALMACEN_PASATIEMPO } from "./accesoBd.js"

/**
 * @param { string } uuid
 */
export async function pasatiempoBusca(uuid) {
 return bdConsulta(accesoBd, [NOMBRE_DEL_ALMACEN_PASATIEMPO],
  /**
   * @param { IDBTransaction } transaccion 
   * @param { (resultado: Pasatiempo|undefined) => any } resolve 
   */
  (transaccion, resolve) => {
   /* Pide el primer registro de almacén pasatiempo que tenga como
    * llave primaria el valor del parámetro uuid. */
   const consulta =
    transaccion.objectStore(NOMBRE_DEL_ALMACEN_PASATIEMPO).get(uuid)
   /* onsuccess se invoca solo una vez, devolviendo el registro
    * solicitado. */
   consulta.onsuccess = () => {
    /* Se recupera el registro solicitado usando
     *  consulta.result
     * Si el registro no se encuentra se recupera undefined. */
    const objeto = consulta.result
    if (objeto !== undefined) {
     const modelo = leePasatiempo(objeto)
     if (!modelo.eliminado) {
      resolve(modelo)
     }
    }
    resolve(undefined)
   }
  })
}