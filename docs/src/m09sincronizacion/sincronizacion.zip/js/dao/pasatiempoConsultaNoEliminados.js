import {
 bdConsulta
} from "../../lib/js/bdConsulta.js"
import {
 Pasatiempo
} from "../modelo/Pasatiempo.js"
import {
 leePasatiempo
} from "../modelo/leePasatiempo.js"
import {
 ALMACEN_PASATIEMPO, accesoBd
} from "./accesoBd.js"

export async function
 pasatiempoConsultaNoEliminados() {
 return bdConsulta(accesoBd,
  [ALMACEN_PASATIEMPO],
  /**
   * @param {IDBTransaction
   *                 } transaccion 
   * @param {(r: Pasatiempo[])=>any
   *                 } resolve 
   */
  (transaccion, resolve) => {
   /** @type {Pasatiempo[]} */
   const resultado = []
   /* Pide un cursor para recorrer
    * cada uno de los registristros
    * que devuelve la consulta. */
   const consulta = transaccion
    .objectStore(
     ALMACEN_PASATIEMPO)
    .openCursor()
   /* onsuccess se invoca por cada
    * uno de los registros de la
    * consulta y una vez cuando se
    * acaban dichos registros.. */
   consulta.onsuccess = () => {
    /* El cursor que corresponde al
     * registro se recupera con
     * consulta.result */
    const cursor = consulta.result
    if (cursor === null) {
     /* Si el cursor es igual a
      * null, ya no hay más
      * registros que procesar; por
      * lo mismo, se devuelve el
      * resultado con los
      * pasatiempos recuperados,
      * usando resolve(resultado).
      */
     resolve(resultado)
    } else {
     /* Si el cursor es diferente a
      * null, si hay más registros.
      * El registro que sigue se
      * obntiene con cursor.value*/
     let objeto = cursor.value
     const modelo =
      leePasatiempo(objeto)
     if (!modelo.eliminado) {
      resultado.push(modelo)
     }
     /* Busca el siguiente registro
      * de la consulta, que se
      * obtiene la siguiente vez
      * que se invoque la función
      * unsuccess. */
     cursor.continue()
    }
   }
  })
}