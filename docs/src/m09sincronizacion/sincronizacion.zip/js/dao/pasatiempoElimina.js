import {
 bdEjecuta
} from "../../lib/js/bdEjecuta.js"
import {
 ALMACEN_PASATIEMPO, accesoBd
} from "./accesoBd.js"
import {
 pasatiempoBusca
} from "./pasatiempoBusca.js"

/** @param {string} uuid */
export async function
 pasatiempoElimina(uuid) {
 const modelo =
  await pasatiempoBusca(uuid)
 if (modelo !== undefined) {
  modelo.modificacion = Date.now()
  modelo.eliminado = true
  return bdEjecuta(accesoBd,
   [ALMACEN_PASATIEMPO],
   transaccion => {
    const almacenPasatiempo =
     transaccion.objectStore(
      ALMACEN_PASATIEMPO)
    almacenPasatiempo.put(modelo)
   })
 }
}