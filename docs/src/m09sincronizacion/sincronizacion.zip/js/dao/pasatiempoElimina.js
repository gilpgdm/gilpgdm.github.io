import { bdEjecuta } from "../../lib/js/bdEjecuta.js"
import { NOMBRE_DEL_ALMACEN_PASATIEMPO, accesoBd } from "./accesoBd.js"
import { pasatiempoBusca } from "./pasatiempoBusca.js"

/**
 * @param { string } uuid
 */
export async function pasatiempoElimina(uuid) {
 const modelo = await pasatiempoBusca(uuid)
 if (modelo !== undefined) {
  modelo.modificacion = Date.now()
  modelo.eliminado = true
  return bdEjecuta(accesoBd, [NOMBRE_DEL_ALMACEN_PASATIEMPO],
   transaccion => {
    const almacenPasatiempo =
     transaccion.objectStore(NOMBRE_DEL_ALMACEN_PASATIEMPO)
    almacenPasatiempo.put(modelo)
   })
 }
}