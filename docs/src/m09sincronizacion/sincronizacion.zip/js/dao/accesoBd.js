export const ALMACEN_PASATIEMPO =
 "Pasatiempo"
const BD_NOMBRE = "sincronizacion"
const BD_VERSION = 1

/** @type {Promise<IDBDatabase>} */
export const accesoBd =
 new Promise((resolve, reject) => {
  const solicitud = indexedDB.open(
   BD_NOMBRE, BD_VERSION)

  solicitud.onerror =
   () => reject(solicitud.error)

  solicitud.onsuccess =
   () => resolve(solicitud.result)
  /* Automáticamente se inicia una
   * transacción para cambio de
   * versión. */
  solicitud.onupgradeneeded =
   () => {
    const bd = solicitud.result
    /* Como hay cambio de versión,
     * borra el almacén si es que
     * existe. */
    if (bd.objectStoreNames
     .contains(
      ALMACEN_PASATIEMPO)) {
     bd.deleteObjectStore(
      ALMACEN_PASATIEMPO)
    }
    /* Crea el almacén "Pasatiempo"
     * con el campo llave "uuid".*/
    bd.createObjectStore(
     ALMACEN_PASATIEMPO,
     { keyPath: "uuid" })
   }

 })