import { bdEjecuta } from "../../lib/js/bdEjecuta.js"
import { Pasatiempo } from "../modelo/Pasatiempo.js"
import { accesoBd, NOMBRE_DEL_ALMACEN_PASATIEMPO } from "./accesoBd.js"
import { pasatiempoBusca } from "./pasatiempoBusca.js"

/**
 * @param { Pasatiempo } modelo
 */
export async function pasatiempoModifica(modelo) {
 modelo.valida()
 const anterior = await pasatiempoBusca(modelo.uuid)
 if (anterior === undefined) {
  return undefined
 } else {
  modelo.modificacion = Date.now()
  modelo.eliminado = false
  return bdEjecuta(accesoBd, [NOMBRE_DEL_ALMACEN_PASATIEMPO],
   transaccion => {
    const almacenPasatiempo =
     transaccion.objectStore(NOMBRE_DEL_ALMACEN_PASATIEMPO)
    almacenPasatiempo.put(modelo)
   })
 }
}