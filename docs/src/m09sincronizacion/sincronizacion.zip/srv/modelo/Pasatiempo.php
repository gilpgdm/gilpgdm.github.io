<?php

class Pasatiempo
{
 public string $uuid;
 public string $nombre;
 public int $modificacion;
 public bool $eliminado;

 public function __construct(
  string $nombre = "",
  string $uuid = "",
  int $modificacion = 0,
  bool $eliminado = true
 ) {
  $this->nombre = $nombre;
  $this->uuid = $uuid;
  $this->modificacion = $modificacion;
  $this->eliminado = $eliminado;
 }

 public function valida()
 {
  if ($this->uuid === "")
   throw new Exception("Falta el uuid.");
  if ($this->nombre === "")
   throw new Exception("Falta el nombre.");
 }
}
