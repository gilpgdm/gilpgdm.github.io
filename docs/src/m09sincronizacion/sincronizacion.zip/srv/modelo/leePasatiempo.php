<?php

require_once __DIR__ .
 "/Pasatiempo.php";

function leePasatiempo(
 $objeto
) {
 if (
  !isset($objeto->nombre)
  || !is_string($objeto->nombre)
 )
  throw new Exception(
   "El nombre debe ser texto."
  );
 $nombre = $objeto->nombre;
 if (
  !isset($objeto->uuid)
  || !is_string($objeto->uuid)
 )
  throw new Exception(
   "El uuid debe ser texto."
  );
 $uuid = $objeto->uuid;
 if (
  !isset($objeto->eliminado)
  || !is_bool($objeto->eliminado)
 )
  throw new Exception(
   "El campo eliminado debe ser "
    . "booleano."
  );
 $eliminado = $objeto->eliminado;
 if (
  !isset($objeto->modificacion)
  || !is_int($objeto->modificacion)
 )
  throw new Exception(
   "La modificacion debe ser "
    . "número."
  );
 $modificacion =
  $objeto->modificacion;
 return new Pasatiempo(
  $nombre,
  $uuid,
  $modificacion,
  $eliminado
 );
}
