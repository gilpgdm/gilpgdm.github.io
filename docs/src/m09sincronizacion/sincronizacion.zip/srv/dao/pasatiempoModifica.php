<?php

require_once __DIR__ . "/../modelo/Pasatiempo.php";
require_once __DIR__ . "/AccesoBd.php";

function pasatiempoModifica(Pasatiempo $modelo)
{
 $modelo->valida();
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "UPDATE PASATIEMPO
   SET
    PAS_NOMBRE = :nombre,
    PAS_MODIFICACION = :modificacion,
    PAS_ELIMINADO = :eliminado
   WHERE PAS_UUID = :uuid"
 );
 $stmt->execute([
  ":uuid" => $modelo->uuid,
  ":nombre" => $modelo->nombre,
  ":modificacion" => $modelo->modificacion,
  ":eliminado" => $modelo->eliminado ? 1 : 0
 ]);
}
