<?php

require_once __DIR__ . "/../modelo/Pasatiempo.php";
require_once __DIR__ . "/AccesoBd.php";

function pasatiempoAgrega(Pasatiempo $modelo) {
 $modelo->valida();
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "INSERT INTO PASATIEMPO
    (PAS_UUID, PAS_NOMBRE, PAS_MODIFICACION, PAS_ELIMINADO)
   VALUES
    (:uuid, :nombre, :modificacion, :eliminado)"
 );
 $stmt->execute([
  ":uuid" => $modelo->uuid,
  ":nombre" => $modelo->nombre,
  ":modificacion" => $modelo->modificacion,
  ":eliminado" => $modelo->eliminado ? 1 : 0
 ]);
}
