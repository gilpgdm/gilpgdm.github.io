<?php

function bdCrea(PDO $con)
{
 $con->exec(
  'CREATE TABLE IF NOT EXISTS
    PASATIEMPO (
     PAS_UUID TEXT NOT NULL,
     PAS_NOMBRE TEXT NOT NULL,
     PAS_MODIFICACION INTEGER
                      NOT NULL,
     PAS_ELIMINADO INTEGER
                   NOT NULL,
     CONSTRAINT PAS_PK
      PRIMARY KEY(PAS_UUID)
    )'
 );
}
