<?php

require_once __DIR__ .
 "/../modelo/Pasatiempo.php";
require_once __DIR__ .
 "/AccesoBd.php";

function pasatiempoBusca(
 string $uuid
): false|Pasatiempo {
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "SELECT
    PAS_UUID AS uuid,
    PAS_NOMBRE AS nombre,
    PAS_MODIFICACION
     AS modificacion,
    PAS_ELIMINADO AS eliminado
   FROM PASATIEMPO
   WHERE PAS_UUID = :uuid"
 );
 $stmt->execute(
  [":uuid" => $uuid]
 );
 $stmt->setFetchMode(
  PDO::FETCH_CLASS
   | PDO::FETCH_PROPS_LATE,
  Pasatiempo::class
 );
 return $stmt->fetch();
}
