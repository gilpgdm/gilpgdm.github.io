<?php

require_once __DIR__ .
 "/../lib/php/Servicio.php";
require_once  __DIR__ .
 "/../lib/php/leeJson.php";
require_once __DIR__ .
 "/modelo/Pasatiempo.php";
require_once __DIR__ .
 "/modelo/leePasatiempo.php";
require_once __DIR__ .
 "/dao/pasatiempoAgrega.php";
require_once __DIR__ .
 "/dao/pasatiempoBusca.php";
require_once  __DIR__ . "/dao/" .
 "pasatiempoConsultaNoEliminados.php";
require_once __DIR__ .
 "/dao/pasatiempoModifica.php";

class SrvSincro extends Servicio
{
 protected
 function implementacion()
 {
  $lista = leeJson();
  if (!is_array($lista)) {
   $lista = [];
  }
  foreach ($lista as $objeto) {
   $modeloEnElCliente =
    leePasatiempo($objeto);
   $modeloEnElServidor =
    pasatiempoBusca(
     $modeloEnElCliente->uuid
    );
   if (
    $modeloEnElServidor === false
   ) {
    /* CONFLICTO. El objeto no ha
     * estado en el servidor.
     * AGREGARLO solamente si no
     * está eliminado. */
    if (
     !$modeloEnElCliente->eliminado
    ) {
     pasatiempoAgrega(
      $modeloEnElCliente
     );
    }
   } elseif (
    !$modeloEnElServidor->eliminado
    &&
    $modeloEnElCliente->eliminado
   ) {
    /* CONFLICTO. El registro está
     * en el servidor, donde no se
     * ha eliminado, pero ha sido
     * eliminado en el cliente.
     * Gana el cliente, porque
     * optamos por no revivir lo
     * que se ha borrado. */
    pasatiempoModifica(
     $modeloEnElCliente
    );
   } else if (
    !$modeloEnElCliente->eliminado
    &&
    !$modeloEnElServidor->eliminado
   ) {
    /* CONFLICTO. El registro está
     * tanto en el servidor como
     * en el cliente. Los datos
     * pueden ser diferentes.
     * PREVALECE LA FECHA MÁS
     * GRANDE. Cuando gana el
     * servidor no se hace nada.*/
    if (
     $modeloEnElCliente
     ->modificacion
     > $modeloEnElServidor
     ->modificacion
    ) {
     /* La versión del cliente es
      * más nueva y prevalece. */
     pasatiempoModifica(
      $modeloEnElCliente
     );
    }
   }
  }
  $lista =
   pasatiempoConsultaNoEliminados();
  return $lista;
 }
}

$servicio = new SrvSincro();
$servicio->ejecuta();
