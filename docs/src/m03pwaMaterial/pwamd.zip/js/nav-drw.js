import { calculaClase } from "../lib/js/calculaClase.js"
import { MdNavigationDrawer } from "../lib/js/custom/MdNavigationDrawer.js"
import { html } from "../lib/js/html.js"

export class NavDrw extends MdNavigationDrawer {

 /**
  * @param {string} paginaActual
  */
 getHipervinculos(paginaActual) {
  return html`
   <li><h1>PWA con MD</h1></li>

   <li>
    <a ${calculaClase("index", paginaActual)}
      href="index.html">
     <span class="material-symbols-outlined">home</span>
     Inicio
    </a>
   </li>

   <li>
    <a ${calculaClase("secundaria", paginaActual)} 
      href="secundaria.html">
     <span class="material-symbols-outlined">scrollable_header</span>
     Página secundaria
    </a>
   </li>

   <li>
    <a ${calculaClase("iconos", paginaActual)} 
      href="iconos.html">
     <span class="material-symbols-outlined">sentiment_satisfied</span>
     Íconos
    </a>
   </li>

   <li>
    <a ${calculaClase("botones", paginaActual)} 
      href="botones.html">
     <span class="material-symbols-outlined">right_click</span>
     Botones
    </a>
   </li>

   <li>
    <a ${calculaClase("campos", paginaActual)} 
      href="campos.html">
     <span class="material-symbols-outlined">password</span>
     Campos de texto
    </a>
   </li>

   <li>
    <a ${calculaClase("select", paginaActual)}
      href="select.html">
     <span class="material-symbols-outlined">bottom_panel_close</span>
     Select
    </a>
   </li>

   <li>
    <a ${calculaClase("interruptor", paginaActual)} 
      href="interruptor.html">
     <span class="material-symbols-outlined">toggle_on</span>
     Interruptores
    </a>
   </li>

   <li>
    <a ${calculaClase("slider", paginaActual)}
      href="slider.html">
     <span class="material-symbols-outlined">linear_scale</span>
     Sliders
    </a>
   </li>

   <li>
    <a ${calculaClase("segmentado", paginaActual)}
      href="segmentado.html">
     <span class="material-symbols-outlined">splitscreen_left</span>
     Botón segmentado
    </a>
   </li>

   <li>
    <a ${calculaClase("one-line", paginaActual)} 
      href="one-line.html">
     <span class="material-symbols-outlined">list</span>
     Listas one-line
    </a>
   </li>

   <li>
    <a ${calculaClase("two-line", paginaActual)} 
      href="two-line.html">
     <span class="material-symbols-outlined">lists</span>
     Listas two-line
    </a>
   </li>

   <li>
    <a ${calculaClase("three-line", paginaActual)} 
      href="three-line.html">
     <span class="material-symbols-outlined">receipt_long</span>
     Listas three-line
    </a>
   </li>

   <li>
    <a ${calculaClase("tarjetas", paginaActual)} 
      href="tarjetas.html">
     <span class="material-symbols-outlined">cards</span>
     Tarjetas
    </a>
   </li>

   <li>
    <a ${calculaClase("navtab", paginaActual)}
      href="navtab.html">
     <span class="material-symbols-outlined">swipe_left</span>
     Pestañas scrollable
    </a>
   </li>

   <li>
    <a ${calculaClase("navTabFixed", paginaActual)}
      href="navTabFixed.html">
     <span class="material-symbols-outlined">tabs</span>
     Pestañas fijas
    </a>
   </li>

   <li>
    <a ${calculaClase("navbar", paginaActual)} 
      href="navbar.html">
     <span class="material-symbols-outlined">bottom_navigation</span>
     Barra de navegación
    </a>
   </li>

   <li>
    <a ${calculaClase("formulario", paginaActual)}
      href="formulario.html">
     <span class="material-symbols-outlined">newspaper</span>
     Formulario
    </a>
   </li>

   <li>
    <a ${calculaClase("ayuda", paginaActual)}
      href="ayuda.html">
     <span class="material-symbols-outlined">help</span>
     Ayuda
    </a>
   </li>
  </ul>`
 }

}

customElements.define("nav-drw", NavDrw)