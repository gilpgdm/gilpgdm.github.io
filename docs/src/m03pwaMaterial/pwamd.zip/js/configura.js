import "../lib/js/md3.js"
import {
 registraServiceWorkerSiEsSoportado
} from "../lib/js/registraServiceWorkerSiEsSoportado.js"

registraServiceWorkerSiEsSoportado(
 "sw.js")