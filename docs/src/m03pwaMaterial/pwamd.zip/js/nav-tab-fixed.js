import { calculaClase } from "../lib/js/calculaClase.js"
import { getAttribute } from "../lib/js/getAttribute.js"
import { html } from "../lib/js/html.js"

export class NavTabFixed extends HTMLElement {

 connectedCallback() {
  this.classList.add("md-tab", "fixed")
  const paginaActual = getAttribute(this, "actual")

  this.innerHTML = html`
   <a ${calculaClase("index", paginaActual)}
     href="index.html">
    <span class="material-symbols-outlined">home</span>
    Inicio
   </a>

   <a ${calculaClase("navTabFixed", paginaActual)}
     href="navTabFixed.html">
    <span class="material-symbols-outlined">tabs</span>
    Pestañas fijas
   </a>

   <a ${calculaClase("navbar", paginaActual)} 
     href="navbar.html">
    <span class="material-symbols-outlined">bottom_navigation</span>
    Barra de navegación
   </a>`.htmlTxt

 }

}

customElements.define("nav-tab-fixed", NavTabFixed)