export class NavTabScrollable
 extends HTMLElement {

 connectedCallback() {
  this.classList
   .add("navTab", "scrollable")

  this.innerHTML = /* html */
   `<a id="aIndex"
      href="index.html">
     <span
 class="material-symbols-outlined">
      home
     </span>
     Inicio
    </a>

    <a id="aSecundario"
      href="secundaria.html">
     <span
class="material-symbols-outlined">
      scrollable_header
     </span>
     Página Secundaria
    </a>

    <a id="aIconos"
      href="iconos.html">
     <span
class="material-symbols-outlined">
      sentiment_satisfied
     </span>
     Íconos
    </a>

    <a id="aCampos"
      href="campos.html">
     <span
 class="material-symbols-outlined">
      password
     </span>
     Campos
    </a>

    <a id="aSlider"
      href="slider.html">
     <span
 class="material-symbols-outlined">
      linear_scale
     </span>
     Sliders
    </a>

    <a id="aSelect"
      href="select.html">
     <span
class="material-symbols-outlined">
      bottom_panel_close
     </span>
     Select
    </a>

    <a id="aBotones"
      href="botones.html">
     <span
class="material-symbols-outlined">
      right_click
     </span>
     Botones
    </a>

    <a id="aSegmentado"
      href="segmentado.html">
     <span
class="material-symbols-outlined">
      splitscreen_left
     </span>
     Botón segmentado
    </a>

    <a id="aListas"
      href="listas.html">
     <span
class="material-symbols-outlined">
      lists
     </span>
     Listas
    </a>

    <a id="aTarjetas"
      href="tarjetas.html">
     <span
class="material-symbols-outlined">
      cards
     </span>
     Tarjetas
    </a>

    <a id="aNavTab"
      href="navtab.html">
     <span
class="material-symbols-outlined">
      swipe_left
     </span>
     Pestañas scrollable
    </a>

    <a id="aNavTabFixed"
      href="navTabFixed.html">
     <span
class="material-symbols-outlined">
      tabs
     </span>
     Pestañas fijas
    </a>

    <a id="aNavBar"
      href="navbar.html">
     <span
class="material-symbols-outlined">
      bottom_navigation
     </span>
     Barra de navegación
    </a>

    <a id="aFormulario"
      href="formulario.html">
     <span
class="material-symbols-outlined">
      newspaper
     </span>
     Formulario
    </a>

    <a id="aAyuda"
      href="ayuda.html">
     <span
 class="material-symbols-outlined">
      help
     </span>
     Ayuda
    </a>`

 }

}

customElements.define(
 "nav-tab-scrollable",
 NavTabScrollable)