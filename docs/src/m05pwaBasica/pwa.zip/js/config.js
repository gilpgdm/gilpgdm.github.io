import {
 regSw
} from "../lib/regSw.js";

regSw("sw.js")