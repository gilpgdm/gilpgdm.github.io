import { msg } from "../lib/msg.js"
import "./config.js";
import {
 CmDin
} from "../lib/cm-din.js"

const REQUERIDO = "*Requerido"

const form =
 document.querySelector("form")

/**
 * @type {HTMLSelectElement|null}
 */
const inGenero = document.
 querySelector("#inGenero")

/**
 * @type {HTMLOutputElement|null}
 */
const msgGenero = document.
 querySelector("#msgGenero")

/**
 * @type {HTMLOutputElement|null}
 */
const outSalida = document.
 querySelector("#outSalida")

if (inGenero && form) {
 form.addEventListener(
  "submit", procesa)
 inGenero.addEventListener("input",
  copiaMensajes)
}

function copiaMensajes() {
 msg(inGenero, msgGenero,
  REQUERIDO)
}

/**
 * @param {SubmitEvent} evt
 */
function procesa(evt) {
 evt.preventDefault()
 if (inGenero !== null
  && outSalida !== null) {
  try {
   if (inGenero.validity.valid) {
    const genero = inGenero.value
    if (genero === "pop") {
     outSalida.value =
      "Escucha a Ariana Grande."
    } else if (genero === "reg") {
     outSalida.value =
      "Escucha a Bad Bunny."
    } else {
     outSalida.value =
      "De ese género no conozco."
    }
   } else {
    outSalida.value = ""
   }
  } catch (e) {
   console.error(e)
   outSalida.value = e.message
  }
  if (outSalida.parentElement
   instanceof CmDin) {
   outSalida.parentElement.
    analiza()
  }
 }
}