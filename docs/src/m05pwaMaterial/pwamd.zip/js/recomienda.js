/** @param {string} genero */
export
 function recomienda(genero) {
 if (genero === "pop") {
  return "Para el pop te " +
   "recomiendo a Dua Lipa."
 } else if (genero === "reg") {
  return "Para el reguetón te " +
   "recomiendo a Bad Bunny."
 }
}