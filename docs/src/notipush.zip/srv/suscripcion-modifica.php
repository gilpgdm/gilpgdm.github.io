<?php

require_once __DIR__ . "/../lib/php/recuperaJson.php";
require_once __DIR__ . "/../lib/php/devuelveCreated.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once  __DIR__ . "/Bd.php";
require_once  __DIR__ . "/Suscripcion.php";
require_once  __DIR__ . "/suscripcionRecupera.php";

try {

 $objeto = recuperaJson();
 $modelo = suscripcionRecupera($objeto);

 $conexion = Bd::getConexion();

 $statement = $conexion->prepare(
  "SELECT
    SUS_ENDPOINT
   FROM SUSCRIPCION
   WHERE SUS_ENDPOINT = :endpoint"
 );
 $statement->execute([":endpoint" => $modelo->endpoint]);

 if ($statement->fetchColumn() === false) {

  $conexion->prepare(
   "INSERT INTO SUSCRIPCION
    (SUS_ENDPOINT, SUS_PUB_KEY, SUS_AUT_TOK, SUS_CONT_ENCOD)
   VALUES
    (:endpoint, :publicKey, :authToken, :contentEncoding)"
  )
   ->execute([
    ":endpoint" => $modelo->endpoint,
    ":publicKey" => $modelo->publicKey,
    ":authToken" => $modelo->authToken,
    ":contentEncoding" => $modelo->contentEncoding
   ]);

  devuelveCreated("", $modelo);
 } else {

  $conexion->prepare(
   "UPDATE SUSCRIPCION
    SET
     SUS_PUB_KEY = :publicKey,
     SUS_AUT_TOK = :authToken,
     SUS_CONT_ENCOD = :contentEncoding
    WHERE SUS_ENDPOINT = :endpoint"
  )
   ->execute([
    ":endpoint" => $modelo->endpoint,
    ":publicKey" => $modelo->publicKey,
    ":authToken" => $modelo->authToken,
    ":contentEncoding" => $modelo->contentEncoding
   ]);

  devuelveJson($modelo);
 }
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
