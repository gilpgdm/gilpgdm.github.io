<?php

require_once  __DIR__ . "/../lib/php/recuperaJson.php";
require_once __DIR__ . "/../lib/php/devuelveNoContent.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once  __DIR__ . "/Bd.php";
require_once  __DIR__ . "/suscripcionRecupera.php";
require_once  __DIR__ . "/suscripcionElimina.php";

try {

 $objeto = recuperaJson();
 $modelo = suscripcionRecupera($objeto);
 suscripcionElimina($modelo->endpoint);
 devuelveNoContent();
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
