<?php

require_once  __DIR__ . "/../lib/php/fetchAll.php";
require_once  __DIR__ . "/Bd.php";
require_once  __DIR__ . "/Suscripcion.php";

function suscripcionConsulta()
{
 $conexion = Bd::getConexion();
 return fetchAll(
  $conexion->query(
   "SELECT
    SUS_ENDPOINT as endpoint,
    SUS_PUB_KEY as publicKey,
    SUS_AUT_TOK as authToken,
    SUS_CONT_ENCOD as contentEncoding
   FROM SUSCRIPCION"
  ),
  [],
  PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE,
  Suscripcion::class
 );
}
