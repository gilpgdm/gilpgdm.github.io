<?php

require_once  __DIR__ . "/Bd.php";

function suscripcionElimina(string $endpoint)
{
 $con = Bd::getConexion();
 $stmt = $con->prepare(
  "DELETE FROM SUSCRIPCION
   WHERE SUS_ENDPOINT = :endpoint"
 );
 $stmt->execute([":endpoint" => $endpoint]);
}
