if (self instanceof ServiceWorkerGlobalScope) {
 // El siguiente código se activa cuando llega una notificación push.
 self.addEventListener("push", (/** @type {PushEvent} */ evt) => {
  const notificacion = evt.data
  /* Si el navegador tiene permitido mostrar notificaciones push,
   * nuestra la que se ha recibido. */
  if (notificacion !== null && self.Notification.permission === 'granted') {
   evt.waitUntil(muestraNotificacion(notificacion))
  }
 })
}

/**
 * @param {PushMessageData} notificacion
 */
async function muestraNotificacion(notificacion) {
 if (self instanceof ServiceWorkerGlobalScope) {
  const mensaje = notificacion.text()
  await self.registration.showNotification(mensaje)
 }
}