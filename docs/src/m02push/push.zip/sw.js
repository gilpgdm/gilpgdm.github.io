if (self instanceof
 ServiceWorkerGlobalScope) {
 self.addEventListener("push",
  notifica)
}
/** @param {PushEvent} evt */
async function notifica(evt) {
 const data = evt.data
 if (data !== null
  && self instanceof
  ServiceWorkerGlobalScope
  && self.Notification
   .permission === 'granted') {
  const mensaje = data.text()
  evt.waitUntil(
   self.registration.
    showNotification(mensaje))
 }
}