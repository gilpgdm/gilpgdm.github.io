<?php

/**
 * Recupera un valor enviado al
 * servicio por medio de GET, POST
 * o cookie.
 */
function leeValor(
 string $cue
): string {
 $valor =
  isset($_REQUEST[$cue])
  ? $_REQUEST[$cue]
  : "";
 return $valor;
}
