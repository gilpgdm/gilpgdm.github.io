<?php
require_once __DIR__ .
 "/dao/usuarioVerifica.php";
require_once __DIR__ .
 "/../lib/php/Servicio.php";
require_once __DIR__ .
 "/../lib/php/leeValor.php";
 require_once __DIR__ .
 "/textos/txtDatosIncorrectos.php";

session_start();
class SrvLogin extends Servicio
{
 protected
 function implementacion()
 {
  $cue = leeValor("cue");
  $match = leeValor("match");
  if (
   usuarioVerifica($cue, $match)
  ) {
   $_SESSION["cue"] = $cue;
   return ["cue" => $cue];
  } else {
   throw new Exception(
    txtDatosIncorrectos()
   );
  }
 }
}

$servicio =
 new SrvLogin();
$servicio->ejecuta();
