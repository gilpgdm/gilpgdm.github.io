<?php
require_once __DIR__ .
 "/../lib/php/Servicio.php";

class SrvLogout extends Servicio
{
 protected
 function implementacion()
 {
  session_start();
  if (isset($_SESSION["cue"])) {
   unset($_SESSION["cue"]);
  }
  session_destroy();
  return [];
 }
}

$servicio = new SrvLogout();
$servicio->ejecuta();
