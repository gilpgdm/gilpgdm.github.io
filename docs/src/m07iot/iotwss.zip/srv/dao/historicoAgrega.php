<?php

use srv\dao\AccesoBd;
use srv\modelo\Dispositivo;

function historicoAgrega(
 Dispositivo $dispositivo
) {
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "INSERT INTO HISTORICO
    (DIS_ID, HIS_VALOR,
     HIS_TIMESTAMP)
    VALUES
     (:dis, :valor, date('now'))"
 );
 $stmt->execute([
  ":dis" => $dispositivo->id,
  ":valor" => $dispositivo->valor
 ]);
}
