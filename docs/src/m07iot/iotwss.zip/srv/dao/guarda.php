<?php

require_once
 "srv/dao/dispositivoModifica.php";
require_once
 "srv/dao/historicoAgrega.php";

use srv\modelo\Dispositivo;

function guarda($valor)
{
 try {
  $dispositivo = new Dispositivo();
  $dispositivo->id = "1";
  $dispositivo->valor = $valor;
  dispositivoModifica(
   $dispositivo
  );
  historicoAgrega($dispositivo);
 } catch (\Throwable $e) {
  echo $e->getMessage();
 }
}
