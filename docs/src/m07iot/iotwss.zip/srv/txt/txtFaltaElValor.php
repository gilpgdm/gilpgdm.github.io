<?php

function txtFaltaElValor()
{
 return "Falta el valor.";
}
