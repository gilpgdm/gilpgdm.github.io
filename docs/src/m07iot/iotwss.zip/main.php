<?php

require_once __DIR__ .
 "/lib/php/autoload.php";
require __DIR__ .
 '/vendor/autoload.php';
require_once
 "srv/dao/dispositivoBusca.php";

use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use srv\IotWss;

try {
 $dispositivo =
  dispositivoBusca("1");
 $valor = $dispositivo
  ? $dispositivo->valor : "0";
 $server = IoServer::factory(
  new HttpServer(
   new WsServer(
    new IotWss($valor)
   )
  ),
  3000
 );

 $server->run();
} catch (\Throwable $e) {
 echo $e->getMessage();
}
